"""Assemble the notebook: hand-written cells + one cell per SQL stage (SQL files are the single source of truth)."""
import re, json, pathlib, nbformat
root = pathlib.Path(__file__).parent; nb_dir = root/'nb'; sql_dir = root/'sql'
def cells_from(text):
    out=[]; cur=None
    for line in text.splitlines():
        if line.startswith('# %%'):
            if cur: out.append(cur)
            cur={'md':'[markdown]' in line,'lines':[]}
        elif cur is not None: cur['lines'].append(line)
    if cur: out.append(cur)
    res=[]
    for c in out:
        src='\n'.join(c['lines']).strip('\n')
        if c['md']: src='\n'.join(l[2:] if l.startswith('# ') else l.lstrip('#') for l in src.splitlines()); res.append(nbformat.v4.new_markdown_cell(src))
        else: res.append(nbformat.v4.new_code_cell(src))
    return res
STAGES=[('00_params','4. SQL pipeline','Parameters: the single date input is passed in here; the 48-month window is derived from it.',True),
        ('01_base','','One pass over the fact table for all 48 months (replaces SAS core + m1..m7 + the 48 monthly step-2 queries).',False),
        ('02_core','','Account history: unbroken-run lengths for each MIA / ATBR definition (replaces the 48-character SAS strings).',False),
        ('02b_core_flags','','Roll-in / held / roll-out flags, payment rating and expected arrears (SAS steps 4-5).',False),
        ('03_lookups','','Snapshot-month lookups: account detail, CMS, deceased, redemption statements (SAS step 6).',False),
        ('04_outputs','','Summary, RAG, LTA lists and next roll-in / roll-out forecasts (SAS steps 4-7).',False),
        ('05_additional','','Arrangement and vulnerability data for LTA cases (SAS step 9).',False)]
cells=[]
cells+=cells_from((nb_dir/'a_head.py').read_text())
cells.append(nbformat.v4.new_markdown_cell("## 4. SQL pipeline\nEach cell runs one stage on the same connection (the `#temp` tables live for this run only – nothing is written to the database). The SQL is plain T-SQL, so any stage can also be pasted into SSMS."))
for name,_,desc,first in STAGES:
    sql=(sql_dir/f'{name}.sql').read_text().strip()
    code=f'SQL_{name[:2]}{"b" if name.endswith("flags") else ""} = r"""\n{sql}\n"""\n'
    var=code.split(' =')[0]
    run=f'run_sql({var}, (MONTH_START,), "{name}")' if first else f'run_sql({var}, label="{name}")'
    cells.append(nbformat.v4.new_markdown_cell(f"**{name}** – {desc}"))
    cells.append(nbformat.v4.new_code_cell(code+run))
cells+=cells_from((nb_dir/'c_checks.py').read_text())
cells+=cells_from((nb_dir/'d_outputs.py').read_text())
cells+=cells_from((nb_dir/'e_tail.py').read_text())
nb=nbformat.v4.new_notebook(cells=cells); nb.metadata['kernelspec']={'display_name':'Python 3','language':'python','name':'python3'}
nbformat.write(nb, root/'LTA_Report_Pipeline.ipynb'); print(len(cells),'cells')
