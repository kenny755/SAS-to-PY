import sys, duckdb, synth, test_harness as th, traceback
def make(snapshot='2026-10-01'):
    con = duckdb.connect(); synth.build(con); 
    for f in ['00_params.sql','01_base.sql','02_core.sql','02b_core_flags.sql','03_lookups.sql','04_outputs.sql','05_additional.sql']:
        try: th.run_file(con, f, snapshot)
        except Exception as e:
            print('FAILED in', f); print(str(e)[:1500]); raise
    return con
if __name__=='__main__':
    con = make()
    for t in ['params','months','fm','core','enriched','summary_long','rag','lta_lists','nextroll_in','nextroll_out','new','addlta','lta_list']:
        print(t, con.execute(f'select count(*) from {t}').fetchone()[0])
