/* 01_base: ONE pass over the fact table for all 48 months (replaces SAS core + m1..m7 + 48 x step-2 queries).
   Filters are identical to the SAS ones. One row per account per month. */
SELECT  mo.MonthOffset
      , CASE WHEN lu.Allocated_AccountNumber IS NOT NULL THEN lu.Allocated_AccountNumber ELSE da.AccountNumber END AS AccountNumber
      , da.AccountStartDate
      , da.AccountEndDate
      , dm.BatchDate
      , fma.CapitalBalanceLive
      , CASE WHEN dc.CompanyName IN ('Amber Homeloans Ltd','North Yorkshire Mortgages') AND fma.StandardArrearsAmount>0 THEN fma.StandardArrearsAmount
             WHEN dc.CompanyName IN ('Skipton Building Society') AND fma.ContractualArrearsAmount>0 THEN fma.ContractualArrearsAmount
             ELSE 0 END AS ArrAmt
      , CASE WHEN dc.CompanyName IN ('Amber Homeloans Ltd','North Yorkshire Mortgages') THEN fma.StandardArrearsInMonths
             WHEN dc.CompanyName IN ('Skipton Building Society') THEN fma.ContractualArrearsInMonths END AS MIARaw
      , CASE WHEN das.AccountStatus='Possession' THEN 1 ELSE 0 END AS Pos
      , CASE WHEN dpd.PK_Date IS NULL THEN 0 ELSE 1 END AS PossDateMatched
      , CASE WHEN dpd.CalendarYear*100+dpd.CalendarMonthNumber=dm.CalendarMonthYear THEN 1 ELSE 0 END AS RepLM
      , CASE WHEN YEAR(da.AccountEndDate)*100+MONTH(da.AccountEndDate)=dm.CalendarMonthYear THEN 1 ELSE 0 END AS RedLM
INTO    #fm
FROM    P_DW.dbo.factMortgageAccountMonthSS fma
INNER JOIN P_DW.dbo.dimAccount da         ON fma.FK_Account = da.PK_Account
INNER JOIN P_DW.dbo.dimCompany dc         ON fma.FK_Company = dc.PK_Company
INNER JOIN P_DW.dbo.dimAccountStates das  ON fma.FK_AccountStates = das.PK_AccountStates
INNER JOIN P_DW.dbo.dimProduct dp         ON fma.FK_CurrentMortgageProduct = dp.PK_Product
INNER JOIN P_DW.dbo.dimMonth dm           ON fma.FK_SnapshotDate = dm.PK_Month
INNER JOIN #months mo                     ON dm.CalendarMonthYear = mo.Yyyymm
LEFT JOIN  P_DW.dbo.dimDate dpd           ON fma.FK_PossessionDate = dpd.PK_Date
LEFT JOIN  P_ODS.reference.AHLNYMMigratedAccounts lu
       ON  da.AccountPool = lu.AHLNYM_PoolID AND da.AccountNumber = lu.AHLNYM_AccountNumber
WHERE   dc.CompanyName IN ('Skipton Building Society','Amber Homeloans Ltd','North Yorkshire Mortgages')
AND     da.AccountPool<>'DRC00001'
AND     da.AccountSubType='Primary'
AND     da.CurrentAccountClassification<>'Pure Commercial'
AND     da.AccountStartDate IS NOT NULL /*Removes Delayed Completions*/
AND     dp.ProductCode NOT IN ('MIN01','HOM10','HM120','HM121','HM122','HM123','HM124','HM125') /*SBS deed accounts + Holmesdale deed and fair value accounts*/
AND     (das.AccountStatus IN ('Live','Possession') OR
        (da.AccountEndDate IS NOT NULL AND YEAR(da.AccountEndDate)*100+MONTH(da.AccountEndDate)=dm.CalendarMonthYear)); /*Includes month end redemptions*/

/* Month-level flags derived once (Y/N columns of SAS step 2 become 1/0) */
SELECT  f.MonthOffset, f.AccountNumber, f.Pos, f.ArrAmt
      , CASE WHEN f.CapitalBalanceLive<=0 THEN 0 ELSE f.CapitalBalanceLive END AS Bal
      , CASE WHEN f.MIARaw>=1 THEN 1 ELSE 0 END AS M1P
      , CASE WHEN f.MIARaw>=3 THEN 1 ELSE 0 END AS M3P
      , CASE WHEN f.MIARaw>=6 THEN 1 ELSE 0 END AS M6P
      , CASE WHEN f.CapitalBalanceLive>0 AND f.ArrAmt>0 AND ROUND((f.ArrAmt/f.CapitalBalanceLive)*100,6)>=0.8333 THEN 1 ELSE 0 END AS R1P
      , CASE WHEN f.CapitalBalanceLive>0 AND f.ArrAmt>0 AND ROUND((f.ArrAmt/f.CapitalBalanceLive)*100,6)>=2.4999 THEN 1 ELSE 0 END AS R3P
      , CASE WHEN f.CapitalBalanceLive>0 AND f.ArrAmt>0 AND ROUND((f.ArrAmt/f.CapitalBalanceLive)*100,6)>=4.9998 THEN 1 ELSE 0 END AS R6P
INTO    #hist
FROM    #fm f;
