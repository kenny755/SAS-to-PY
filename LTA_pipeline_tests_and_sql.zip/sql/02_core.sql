/* 02_core: SAS steps 1, 3, 4 (flags) and 5 (rating / expected arrears) at account level.
   SAS built 48 x 6 Y/N columns, concatenated them into 48-character strings and used INDEX()/SUBSTR().
   Equivalent here without strings:
     Dur     = length of the unbroken run of Y starting at the snapshot month        (= INDEX(string,'N')-1, or 48)
     DurPrev = length of the unbroken run of Y starting one month earlier             (= SUBSTR(string,2,k)='Y..Y' test for k <= DurPrev)
   A month where the account is absent counts as 'N', exactly as the SAS merge left it blank -> 'N'. */

/* Rows where the flag is Y, numbered in month order; the run is unbroken while MonthOffset = row number - 1 */
SELECT  y.AccountNumber, y.Series, y.MonthOffset
      , ROW_NUMBER() OVER (PARTITION BY y.AccountNumber, y.Series ORDER BY y.MonthOffset) AS rn
      , ROW_NUMBER() OVER (PARTITION BY y.AccountNumber, y.Series, CASE WHEN y.MonthOffset>=1 THEN 1 ELSE 0 END ORDER BY y.MonthOffset) AS rn1
INTO    #yrows
FROM   (SELECT h.AccountNumber, h.MonthOffset, s.Series
        FROM   #hist h
        CROSS APPLY (VALUES ('M1P',h.M1P),('M3P',h.M3P),('M6P',h.M6P),('R1P',h.R1P),('R3P',h.R3P),('R6P',h.R6P)) s(Series,Flag)
        WHERE  s.Flag=1) y;

SELECT  r.AccountNumber
      , COUNT(CASE WHEN r.Series='M1P' AND r.MonthOffset=r.rn-1 THEN 1 END) AS M1PDur
      , COUNT(CASE WHEN r.Series='M3P' AND r.MonthOffset=r.rn-1 THEN 1 END) AS M3PDur
      , COUNT(CASE WHEN r.Series='M6P' AND r.MonthOffset=r.rn-1 THEN 1 END) AS M6PDur
      , COUNT(CASE WHEN r.Series='R1P' AND r.MonthOffset=r.rn-1 THEN 1 END) AS R1PDur
      , COUNT(CASE WHEN r.Series='R3P' AND r.MonthOffset=r.rn-1 THEN 1 END) AS R3PDur
      , COUNT(CASE WHEN r.Series='R6P' AND r.MonthOffset=r.rn-1 THEN 1 END) AS R6PDur
      , COUNT(CASE WHEN r.Series='M1P' AND r.MonthOffset>=1 AND r.MonthOffset=r.rn1 THEN 1 END) AS M1PDurPrev
      , COUNT(CASE WHEN r.Series='M3P' AND r.MonthOffset>=1 AND r.MonthOffset=r.rn1 THEN 1 END) AS M3PDurPrev
      , COUNT(CASE WHEN r.Series='M6P' AND r.MonthOffset>=1 AND r.MonthOffset=r.rn1 THEN 1 END) AS M6PDurPrev
      , COUNT(CASE WHEN r.Series='R1P' AND r.MonthOffset>=1 AND r.MonthOffset=r.rn1 THEN 1 END) AS R1PDurPrev
      , COUNT(CASE WHEN r.Series='R3P' AND r.MonthOffset>=1 AND r.MonthOffset=r.rn1 THEN 1 END) AS R3PDurPrev
      , COUNT(CASE WHEN r.Series='R6P' AND r.MonthOffset>=1 AND r.MonthOffset=r.rn1 THEN 1 END) AS R6PDurPrev
INTO    #dur
FROM    #yrows r
GROUP BY r.AccountNumber;

/* Last 7 months' balance / arrears (SAS m1..m7) and prior-month possession flag (Pos2) */
SELECT  h.AccountNumber
      , MAX(CASE WHEN h.MonthOffset=0 THEN h.Bal END) AS Bal1, MAX(CASE WHEN h.MonthOffset=0 THEN h.ArrAmt END) AS Arr1
      , MAX(CASE WHEN h.MonthOffset=1 THEN h.Bal END) AS Bal2, MAX(CASE WHEN h.MonthOffset=1 THEN h.ArrAmt END) AS Arr2
      , MAX(CASE WHEN h.MonthOffset=2 THEN h.Bal END) AS Bal3, MAX(CASE WHEN h.MonthOffset=2 THEN h.ArrAmt END) AS Arr3
      , MAX(CASE WHEN h.MonthOffset=3 THEN h.Bal END) AS Bal4, MAX(CASE WHEN h.MonthOffset=3 THEN h.ArrAmt END) AS Arr4
      , MAX(CASE WHEN h.MonthOffset=4 THEN h.Bal END) AS Bal5, MAX(CASE WHEN h.MonthOffset=4 THEN h.ArrAmt END) AS Arr5
      , MAX(CASE WHEN h.MonthOffset=5 THEN h.Bal END) AS Bal6, MAX(CASE WHEN h.MonthOffset=5 THEN h.ArrAmt END) AS Arr6
      , MAX(CASE WHEN h.MonthOffset=6 THEN h.Bal END) AS Bal7, MAX(CASE WHEN h.MonthOffset=6 THEN h.ArrAmt END) AS Arr7
      , MAX(CASE WHEN h.MonthOffset=1 THEN h.Pos END) AS Pos2
INTO    #last7
FROM    #hist h
WHERE   h.MonthOffset<=6
GROUP BY h.AccountNumber;

/* Core: snapshot-month accounts + their history (SAS step 1 core, merged with perf and step 3 durations) */
SELECT  f.AccountNumber
      , CONVERT(DATE,f.AccountStartDate) AS CompDate
      , x.AgeDays
      , x.AgeYears
      , CASE WHEN x.AgeYears>=3 AND f.CapitalBalanceLive>0 THEN 1 ELSE 0 END AS Mature
      , CASE WHEN x.AgeYears>=3 AND f.CapitalBalanceLive>0 THEN f.CapitalBalanceLive ELSE 0 END AS MatureBal
      , CASE WHEN f.ArrAmt>0 AND f.CapitalBalanceLive>0 THEN ROUND((f.ArrAmt/f.CapitalBalanceLive)*100,6) ELSE 0 END AS ATBR
      , CASE WHEN f.MIARaw>0 THEN ROUND(f.MIARaw,3) ELSE 0 END AS MIA
      , f.Pos AS Repossessed
      , f.RepLM
      , f.RedLM
      , l.Bal1, l.Arr1, l.Bal2, l.Arr2, l.Bal3, l.Arr3, l.Bal4, l.Arr4, l.Bal5, l.Arr5, l.Bal6, l.Arr6, l.Bal7, l.Arr7
      , l.Pos2
      , COALESCE(d.M1PDur,0) AS M1PDur, COALESCE(d.M3PDur,0) AS M3PDur, COALESCE(d.M6PDur,0) AS M6PDur
      , COALESCE(d.R1PDur,0) AS R1PDur, COALESCE(d.R3PDur,0) AS R3PDur, COALESCE(d.R6PDur,0) AS R6PDur
      , COALESCE(d.M1PDurPrev,0) AS M1PDurPrev, COALESCE(d.M3PDurPrev,0) AS M3PDurPrev, COALESCE(d.M6PDurPrev,0) AS M6PDurPrev
      , COALESCE(d.R1PDurPrev,0) AS R1PDurPrev, COALESCE(d.R3PDurPrev,0) AS R3PDurPrev, COALESCE(d.R6PDurPrev,0) AS R6PDurPrev
INTO    #core_a
FROM    #fm f
CROSS APPLY (SELECT CASE WHEN f.AccountStartDate IS NULL OR f.AccountStartDate>f.BatchDate THEN 0 ELSE DATEDIFF(DAY,f.AccountStartDate,f.BatchDate) END AS AgeDays
                   , CASE WHEN f.AccountStartDate IS NULL OR f.AccountStartDate>f.BatchDate THEN 0
                          ELSE ROUND(CONVERT(FLOAT,(DATEDIFF(DAY,f.AccountStartDate,f.BatchDate)))/365,2) END AS AgeYears) x
LEFT JOIN #last7 l ON l.AccountNumber=f.AccountNumber
LEFT JOIN #dur   d ON d.AccountNumber=f.AccountNumber
WHERE   f.MonthOffset=0;
