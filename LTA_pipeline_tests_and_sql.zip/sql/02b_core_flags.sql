/* 02b: SAS step 4 account-level flags + step 5 (payment rating, average arrears reduction, expected arrears).
   SAS treats a missing number as smaller than any number in comparisons; arrears are never negative,
   so COALESCE(arrears,-1) reproduces that behaviour exactly. In MAX(0,x) a missing x counts as 0. */
SELECT  a.*
      , CASE WHEN a.M6PDur=12 AND a.Repossessed=0 THEN 1 ELSE 0 END AS MLTAIn
      , CASE WHEN a.M6PDur>12 AND a.M6PDur<=24 AND a.Repossessed=0 THEN 1 ELSE 0 END AS MLTAHeld1
      , CASE WHEN a.M6PDur>24 AND a.M6PDur<=36 AND a.Repossessed=0 THEN 1 ELSE 0 END AS MLTAHeld2
      , CASE WHEN a.M6PDur>36 AND a.Repossessed=0 THEN 1 ELSE 0 END AS MLTAHeld3
      , CASE WHEN a.M6PDurPrev>=12 AND ((a.M6PDur=0 AND a.Pos2=0) OR a.RepLM=1) THEN 1 ELSE 0 END AS MLTAOut
      , CASE WHEN a.M6PDur=11 AND a.Repossessed=0 THEN 1 ELSE 0 END AS NextIn_1M
      , CASE WHEN a.M6PDur=10 AND a.Repossessed=0 THEN 1 ELSE 0 END AS NextIn_2M
      , CASE WHEN a.M6PDur=9  AND a.Repossessed=0 THEN 1 ELSE 0 END AS NextIn_3M
      , rt.Rating
      , rt.AvArrRed
      , CASE WHEN rt.Rating='Green' OR (rt.Rating='Amber' AND rt.AvArrRed>0) THEN a.Arr1-(rt.AvArrRed*1) ELSE a.Arr1 END AS ExpAB1
      , CASE WHEN rt.Rating='Green' OR (rt.Rating='Amber' AND rt.AvArrRed>0) THEN a.Arr1-(rt.AvArrRed*2) ELSE a.Arr1 END AS ExpAB2
      , CASE WHEN rt.Rating='Green' OR (rt.Rating='Amber' AND rt.AvArrRed>0) THEN a.Arr1-(rt.AvArrRed*3) ELSE a.Arr1 END AS ExpAB3
INTO    #core
FROM    #core_a a
CROSS APPLY (SELECT COALESCE(a.Arr1,-1) AS A1, COALESCE(a.Arr2,-1) AS A2, COALESCE(a.Arr3,-1) AS A3
                  , COALESCE(a.Arr4,-1) AS A4, COALESCE(a.Arr5,-1) AS A5, COALESCE(a.Arr6,-1) AS A6, COALESCE(a.Arr7,-1) AS A7) c
CROSS APPLY (SELECT (CASE WHEN c.A1>c.A2 THEN 1 ELSE 0 END) AS Det1, (CASE WHEN c.A2>c.A3 THEN 1 ELSE 0 END) AS Det2
                  , (CASE WHEN c.A3>c.A4 THEN 1 ELSE 0 END) AS Det3, (CASE WHEN c.A4>c.A5 THEN 1 ELSE 0 END) AS Det4
                  , (CASE WHEN c.A1<c.A2 THEN 1 ELSE 0 END) AS Imp1, (CASE WHEN c.A2<c.A3 THEN 1 ELSE 0 END) AS Imp2
                  , (CASE WHEN c.A3<c.A4 THEN 1 ELSE 0 END) AS Imp3) f
CROSS APPLY (SELECT CASE WHEN a.Arr2 IS NOT NULL AND a.Arr2>a.Arr1 THEN a.Arr2-a.Arr1 ELSE 0 END AS Red1
                  , CASE WHEN a.Arr3 IS NOT NULL AND a.Arr2 IS NOT NULL AND a.Arr3>a.Arr2 THEN a.Arr3-a.Arr2 ELSE 0 END AS Red2
                  , CASE WHEN a.Arr4 IS NOT NULL AND a.Arr3 IS NOT NULL AND a.Arr4>a.Arr3 THEN a.Arr4-a.Arr3 ELSE 0 END AS Red3) rd
CROSS APPLY (SELECT CASE WHEN f.Det1=1 OR (f.Det2+f.Det3+f.Det4)>=2 THEN 'Red'
                         WHEN f.Imp1=1 AND f.Imp2=1 AND f.Imp3=1 THEN 'Green'
                         ELSE 'Amber' END AS Rating
                  /* median of three, then ROUND(...,1) in SAS = nearest whole pound */
                  , ROUND(CASE WHEN (rd.Red1>=rd.Red2 AND rd.Red1<=rd.Red3) OR (rd.Red1<=rd.Red2 AND rd.Red1>=rd.Red3) THEN rd.Red1
                               WHEN (rd.Red2>=rd.Red1 AND rd.Red2<=rd.Red3) OR (rd.Red2<=rd.Red1 AND rd.Red2>=rd.Red3) THEN rd.Red2
                               ELSE rd.Red3 END,0) AS AvArrRed) rt;
