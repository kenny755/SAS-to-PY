/* 05_additional: SAS step 9 - arrangement / vulnerability data for LTA, roll-in and held cases (AdditionalLTAData.xlsx, LTA List.xlsx).
   NB: SAS also built Out2 and NextRoll_Out2 but never used them (New = In2 + Held2 + NextRoll_In2), so they are not rebuilt. */

/* Arrangement data (SAS Arrang) */
SELECT  CASE WHEN lu.Allocated_PrimaryAccount IS NOT NULL THEN lu.Allocated_PrimaryAccount ELSE dpa.AccountNumber END AS AccountNumber
      , COUNT(da.AccountNumber) AS NoAcc
      , SUM(fma.AccountCMSCurrent) AS CMS
      , SUM(fma.AccountContractualPaymentArrangement) AS ArrAmn
      , SUM(fma.AccountPaymentThisMonth) AS Paid
INTO    #ap
FROM    P_DW.dbo.factMortgageAccountMonthSS fma
INNER JOIN P_DW.dbo.dimAccount da        ON fma.FK_Account = da.PK_Account
INNER JOIN P_DW.dbo.dimAccount dpa       ON fma.FK_PrimaryAccount = dpa.PK_Account
INNER JOIN P_DW.dbo.dimCompany dc        ON fma.FK_Company = dc.PK_Company
INNER JOIN P_DW.dbo.dimProduct dp        ON fma.FK_CurrentMortgageProduct = dp.PK_Product
INNER JOIN P_DW.dbo.dimMonth dm          ON fma.FK_SnapshotDate = dm.PK_Month
INNER JOIN P_DW.dbo.dimAccountStates das ON fma.FK_AccountStates = das.PK_AccountStates
INNER JOIN P_DW.dbo.dimArrangement dar   ON fma.FK_ArrangementType = dar.PK_ArrangementType
INNER JOIN P_DW.dbo.dimDate darrd        ON fma.FK_DatePaymentArrangementEnd = darrd.PK_Date
LEFT JOIN  P_ODS.reference.AHLNYMMigratedAccounts lu
       ON  da.AccountPool = lu.AHLNYM_PoolID AND da.AccountNumber = lu.AHLNYM_AccountNumber
WHERE   dc.CompanyName IN ('Skipton Building Society','Amber Homeloans Ltd','North Yorkshire Mortgages')
AND     da.AccountPool<>'DRC00001'
AND     dm.CalendarMonthYear=(SELECT Yyyymm FROM #params)
AND     das.AccountStatus IN ('Live')
AND     da.CurrentAccountClassification<>'Pure Commercial'
AND     dp.ProductCode NOT IN ('MIN01','HOM10','HM120','HM121','HM122','HM123','HM124','HM125')
GROUP BY CASE WHEN lu.Allocated_PrimaryAccount IS NOT NULL THEN lu.Allocated_PrimaryAccount ELSE dpa.AccountNumber END;

/* Customers with an active vulnerability recorded (SAS CTE_AR) */
SELECT  DISTINCT da.AccountNumber, 1 AS ARFlag
INTO    #ar
FROM    P_DW.dbo.factMortgageAccount fma
INNER JOIN P_DW.dbo.dimAccount da            ON fma.FK_Account = da.PK_Account
INNER JOIN P_DW.dbo.bridgeAccountCustomer bac ON da.PK_Account = bac.FK_Account
                                             AND bac.DeLinkDate IS NULL AND bac.relationshipTypeCode=19
INNER JOIN P_DW.dbo.dimCustomer dc           ON bac.FK_Customer = dc.PK_Customer
WHERE   da.AccountPool='SBS00001'
AND     da.AccountSubType='Primary'
AND     da.CurrentAccountClassification='Residential'
AND     da.CurrentAccountStatus='Live'
AND     dc.CustomerNumber IN (SELECT DISTINCT c01.custnbr_u
                              FROM   P_ODS.SKIPCORE.DatCustomerVulnerability dcv
                              INNER JOIN P_ODS.SKIPCORE.CUS01 c01 ON dcv.myCustomer = c01.oid AND c01.fndr_id_o='SBS'
                              INNER JOIN P_ODS.SKIPCORE.DatCustomerVulnerability_allMyCategories dvac ON dcv.oid = dvac.DatCustomerVulnerability_oid
                              INNER JOIN P_ODS.SKIPCORE.StcVulnerabilityCategory dvc ON dvac.StcVulnerabilityCategory_oid = dvc.oid
                              WHERE  dcv.removalDate IS NULL);

SELECT  CASE WHEN lu.Allocated_AccountNumber IS NOT NULL THEN lu.Allocated_AccountNumber ELSE da.AccountNumber END AS AccountNumber
      , dar.ArrangementTypeCode AS ArrangementCode
      , dar.ArrangementDescription AS ArrangementDesc
      , CONVERT(DATE,darrd.CalendarDate) AS ArrangementEndDate
      , ap.NoAcc
      , ap.CMS
      , CASE WHEN dar.ArrangementTypeCode=-1 THEN 0 ELSE ap.ArrAmn END AS ArrangementAmn
      , ap.Paid
      , CASE WHEN dar.ArrangementTypeCode=5 AND ap.Paid<ap.CMS THEN 1 /*DD arrangements*/
             WHEN dar.ArrangementTypeCode IN ('63','65','68') AND ap.ArrAmn IN ('0','1') AND ap.Paid<ap.CMS THEN 1 /*DWP Arrangements*/
             WHEN dar.ArrangementTypeCode IN ('63','65','68') AND ap.ArrAmn>1 AND ap.Paid<ap.ArrAmn THEN 1 /*DWP Arrangements*/
             WHEN dar.ArrangementTypeCode=6 AND ap.Paid<ap.ArrAmn THEN 1 /*Concessions*/
             WHEN dar.ArrangementTypeCode=-1 THEN 0 /*No arrangements in place*/
             WHEN dar.ArrangementTypeCode NOT IN ('-1','5','6','63','65','68') AND ap.Paid<ap.ArrAmn AND ap.ArrAmn-ap.Paid>5 THEN 1 /*Other arrangements - Shortfalls over 5 pounds*/
             ELSE 0 END AS BrokenArrangement
      , ISNULL(ar.ARFlag,0) AS ARFlag
INTO    #arrang
FROM    P_DW.dbo.factMortgageAccountMonthSS fma
INNER JOIN P_DW.dbo.dimAccount da        ON fma.FK_Account = da.PK_Account
INNER JOIN P_DW.dbo.dimAccount dpa       ON fma.FK_PrimaryAccount = dpa.PK_Account
INNER JOIN P_DW.dbo.dimCompany dc        ON fma.FK_Company = dc.PK_Company
INNER JOIN P_DW.dbo.dimProduct dp        ON fma.FK_CurrentMortgageProduct = dp.PK_Product
INNER JOIN P_DW.dbo.dimMonth dm          ON fma.FK_SnapshotDate = dm.PK_Month
INNER JOIN P_DW.dbo.dimAccountStates das ON fma.FK_AccountStates = das.PK_AccountStates
INNER JOIN P_DW.dbo.dimArrangement dar   ON fma.FK_ArrangementType = dar.PK_ArrangementType
INNER JOIN P_DW.dbo.dimDate darrd        ON fma.FK_DatePaymentArrangementEnd = darrd.PK_Date
INNER JOIN #ap ap                        ON da.AccountNumber = ap.AccountNumber
LEFT JOIN  #ar ar                        ON da.AccountNumber = ar.AccountNumber
LEFT JOIN  P_ODS.reference.AHLNYMMigratedAccounts lu
       ON  da.AccountPool = lu.AHLNYM_PoolID AND da.AccountNumber = lu.AHLNYM_AccountNumber
WHERE   dc.CompanyName IN ('Skipton Building Society','Amber Homeloans Ltd','North Yorkshire Mortgages')
AND     da.AccountPool<>'DRC00001'
AND     dm.CalendarMonthYear=(SELECT Yyyymm FROM #params)
AND     da.AccountSubType='Primary'
AND     das.AccountStatus IN ('Live')
AND     da.CurrentAccountClassification<>'Pure Commercial'
AND     dp.ProductCode NOT IN ('MIN01','HOM10','HM120','HM121','HM122','HM123','HM124','HM125')
AND     fma.ContractualArrearsInMonths>=1;

/* LTA-type list: roll-ins, held and next roll-ins (SAS In2 + Held2 + NextRoll_In2), joined to arrangement data */
SELECT  n.AccountNumber, n.MIA, n.Rating, n.Lender, n.ArrangementLive, n.Litigation, n.EvictionDate
      , CASE WHEN n.SubPopulationCode='BTL' THEN 'BTL' ELSE 'Resi' END AS AccType
      , n.LTAType
INTO    #new
FROM   (SELECT l.AccountNumber, l.MIA, l.Rating, l.Lender, l.ArrangementLive, l.Litigation, l.EvictionDate, l.SubPopulationCode
              , CASE WHEN l.ListName='LTA_In' THEN 'RolledIn'
                     WHEN l.HeldGroup='LT12M' THEN 'Held<12M'
                     WHEN l.HeldGroup='12_23M' THEN '12M<=Held<23M'
                     ELSE 'Held>=24M' END AS LTAType
        FROM   #lta_lists l WHERE l.ListName IN ('LTA_In','Held')
        UNION ALL
        SELECT r.AccountNumber, r.MIA, r.Rating, r.Lender, r.ArrangementLive, r.Litigation, r.EvictionDate, r.SubPopulationCode
              , CASE r.[Group] WHEN 1 THEN 'NextRollIn1M' WHEN 2 THEN 'NextRollIn2M' ELSE 'NextRollIn3M' END
        FROM   #nextroll_in r WHERE r.[Group]<>0) n;

/* AdditionalLTAData.xlsx (SAS AddLTAdata) */
SELECT  n.AccountNumber, n.MIA, n.Rating, n.Lender, n.ArrangementLive, n.Litigation, n.EvictionDate, n.AccType, n.LTAType
      , a.ArrangementCode, a.ArrangementDesc, a.ArrangementEndDate, a.NoAcc, a.CMS, a.ArrangementAmn, a.Paid, a.BrokenArrangement, a.ARFlag
INTO    #addlta
FROM    #new n
LEFT JOIN #arrang a ON a.AccountNumber=n.AccountNumber;

/* LTA List.xlsx (SAS lta) */
SELECT  n.AccountNumber, n.Lender, n.LTAType
INTO    #lta_list
FROM    #new n
WHERE   n.LTAType IN ('RolledIn','Held<12M','12M<=Held<23M','Held>=24M');
