/* 00_params: single date input -> derived parameters and the 48-month window.
   The only value passed in is the first day of the snapshot month (the SAS &monthend). */
SELECT  p.MonthStart
      , CAST(YEAR(p.MonthStart)*100+MONTH(p.MonthStart) AS VARCHAR(6)) AS Yyyymm
      , RIGHT(CAST(YEAR(p.MonthStart)*100+MONTH(p.MonthStart) AS VARCHAR(6)),4) AS Yymm
      , DATEADD(MONTH,-1,p.MonthStart) AS PrevMonthStart
      , 48 AS MaxMonths /* SAS &max - do not change */
INTO    #params
FROM    (SELECT CAST(? AS DATE) AS MonthStart) p;

WITH n AS (
    SELECT 0 AS MonthOffset
    UNION ALL
    SELECT n.MonthOffset+1 FROM n CROSS JOIN #params p WHERE n.MonthOffset+1<p.MaxMonths
)
SELECT  n.MonthOffset
      , CAST(YEAR(DATEADD(MONTH,-n.MonthOffset,p.MonthStart))*100+MONTH(DATEADD(MONTH,-n.MonthOffset,p.MonthStart)) AS VARCHAR(6)) AS Yyyymm
INTO    #months
FROM    n CROSS JOIN #params p;
