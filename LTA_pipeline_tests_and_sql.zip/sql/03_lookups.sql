/* 03_lookups: snapshot-month lookups (SAS step 6: accounts, CMS, Dec, redsta). Logic unchanged. */

/*Account Data*/
SELECT  CASE WHEN lu.Allocated_AccountNumber IS NOT NULL THEN lu.Allocated_AccountNumber ELSE da.AccountNumber END AS AccountNumber
      , CASE WHEN dc.CompanyName='Amber Homeloans Ltd' OR da.AccountOrigin='Amber Homeloans Ltd' THEN 'AHL'
             WHEN dc.CompanyName='North Yorkshire Mortgages' OR da.AccountOrigin='North Yorkshire Mortgages Ltd' THEN 'NYM'
             ELSE 'SBS' END AS Lender
      , da.AccountNumber AS AccountOriginal
      , da.CurrentAccountClassification
      , dsp.SubPopulationCode
      , CASE WHEN dc.CompanyName IN ('Amber Homeloans Ltd','North Yorkshire Mortgages') AND fma.StandardArrearsInMonths>0 THEN fma.StandardArrearsInMonths
             WHEN dc.CompanyName IN ('Skipton Building Society') AND fma.ContractualArrearsInMonths>0 THEN fma.ContractualArrearsInMonths
             ELSE 0 END AS Contractual_MIA
      , CASE WHEN dc.CompanyName IN ('Amber Homeloans Ltd','North Yorkshire Mortgages') AND fma.StandardArrearsAmount>0 THEN fma.StandardArrearsAmount
             WHEN dc.CompanyName IN ('Skipton Building Society') AND fma.ContractualArrearsAmount>0 THEN fma.ContractualArrearsAmount
             ELSE 0 END AS Contractual_Arrears
      , fma.HalifaxValuation AS HPI_Val
      , ROUND(fma.[HPI LTV],1) AS LTV
      , CASE WHEN drt.RepaymentTypeGroup='Capital & Interest' THEN 'C&I' WHEN drt.RepaymentTypeGroup='Part & Part' THEN 'P&P' ELSE 'I/O' END AS Rep_Type
      , dms.ONSRegionCode AS HPI_Region
      , YEAR(da.AccountStartDate) AS CompletionYear
      , CASE WHEN darr.ArrangementTypeCode<1 THEN 'N' ELSE 'Y' END AS ArrangementLive
      , CASE WHEN da.AccountEndDate IS NULL AND a97.dc_ins_o_dt IS NOT NULL
              AND (a97.dc_wdrwn_o_dt IS NULL OR a97.dc_wdrwn_o_dt < a97.dc_ins_o_dt)
              AND (a97.dc_poses_o_dt IS NULL OR a97.dc_poses_o_dt < a97.dc_ins_o_dt) THEN 'Y' ELSE 'N' END AS Litigation
      , CONVERT(DATE, a97.dc_evict_o_dt) AS EvictionDate
      , CONVERT(DATE, a97.dc_poses_o_dt) AS PossessionDate
      , CONVERT(DATE, a97.dc_wdrwn_o_dt) AS ProceedingsWithdrawnDate
      , CASE WHEN da.AccountEndDate IS NOT NULL AND da.AccountEndDate<dm.ReportingMonth THEN 1 ELSE 0 END AS RedeemedFlag
      , CASE WHEN das.AccountStatus='Possession' THEN 'Y' ELSE 'N' END AS Repossessed_Ind
INTO    #accounts
FROM    P_DW.dbo.factMortgageAccountMonthSS fma
INNER JOIN P_DW.dbo.dimAccount da            ON fma.FK_Account = da.PK_Account
INNER JOIN P_DW.dbo.dimCompany dc            ON fma.FK_Company = dc.PK_Company
INNER JOIN P_DW.dbo.dimRepaymentType drt     ON fma.FK_RepaymentType = drt.PK_RepaymentType
INNER JOIN P_DW.dbo.dimMortgageSecurity dms  ON fma.FK_MortgageSecurity = dms.PK_MortgageSecurity
INNER JOIN P_DW.dbo.dimProduct dp            ON fma.FK_CurrentMortgageProduct = dp.PK_Product
INNER JOIN P_DW.dbo.dimMonth dm              ON fma.FK_SnapshotDate = dm.PK_Month
INNER JOIN P_DW.dbo.dimAccountStates das     ON fma.FK_AccountStates = das.PK_AccountStates
INNER JOIN P_DW.dbo.dimSubPopulation dsp     ON fma.FK_SubPopulation = dsp.PK_SubPopulation
INNER JOIN P_DW.dbo.dimArrangement darr      ON fma.FK_ArrangementType = darr.PK_ArrangementType
LEFT JOIN  P_ODS.reference.AHLNYMMigratedAccounts lu
       ON  da.AccountPool = lu.AHLNYM_PoolID AND da.AccountNumber = lu.AHLNYM_AccountNumber
LEFT JOIN (SELECT b.* FROM (SELECT a.*, RANK() OVER(PARTITION BY a.accnbr_o ORDER BY a.oid DESC, a._timestamp DESC) AS LatestRecord
                            FROM P_ODS.SKIPCORE.ARR97 a WHERE a.pool_id_o='SBS00001') b
           WHERE b.LatestRecord=1) a97
       ON  da.AccountNumber = a97.accnbr_o
WHERE   dc.CompanyName IN ('Skipton Building Society','Amber Homeloans Ltd','North Yorkshire Mortgages')
AND     da.AccountPool<>'DRC00001'
AND     dm.CalendarMonthYear=(SELECT Yyyymm FROM #params)
AND     da.AccountSubType='Primary'
AND     da.CurrentAccountClassification<>'Pure Commercial'
AND     da.AccountStartDate IS NOT NULL /*Removes Delayed Completions*/
AND     dp.ProductCode NOT IN ('MIN01','HOM10','HM120','HM121','HM122','HM123','HM124','HM125')
AND     (das.AccountStatus IN ('Live','Possession') OR
        (da.AccountEndDate IS NOT NULL AND YEAR(da.AccountEndDate)*100+MONTH(da.AccountEndDate)=dm.CalendarMonthYear)); /*Includes month end redemptions*/

/*Account CMS*/
SELECT  CASE WHEN lu.Allocated_PrimaryAccount IS NOT NULL THEN lu.Allocated_PrimaryAccount ELSE dpa.AccountNumber END AS AccountNumber
      , SUM(fma.AccountCMSCurrent) AS CMS_Current
      , SUM(fma.AccountCMSNextMonth) AS CMS_Next
INTO    #cms
FROM    P_DW.dbo.factMortgageAccountMonthSS fma
INNER JOIN P_DW.dbo.dimAccount da        ON fma.FK_Account = da.PK_Account
INNER JOIN P_DW.dbo.dimAccount dpa       ON fma.FK_PrimaryAccount = dpa.PK_Account
INNER JOIN P_DW.dbo.dimCompany dc        ON fma.FK_Company = dc.PK_Company
INNER JOIN P_DW.dbo.dimMonth dm          ON fma.FK_SnapshotDate = dm.PK_Month
INNER JOIN P_DW.dbo.dimAccountStates das ON fma.FK_AccountStates = das.PK_AccountStates
LEFT JOIN  P_ODS.reference.AHLNYMMigratedAccounts lu
       ON  da.AccountPool = lu.AHLNYM_PoolID AND da.AccountNumber = lu.AHLNYM_AccountNumber
WHERE   dc.CompanyName IN ('Skipton Building Society','Amber Homeloans Ltd','North Yorkshire Mortgages')
AND     da.AccountPool<>'DRC00001'
AND     dm.CalendarMonthYear=(SELECT Yyyymm FROM #params)
AND     das.AccountStatus IN ('Live','Possession')
AND     da.CurrentAccountClassification<>'Pure Commercial'
AND     da.AccountStartDate IS NOT NULL /*Removes Delayed Completions*/
GROUP BY CASE WHEN lu.Allocated_PrimaryAccount IS NOT NULL THEN lu.Allocated_PrimaryAccount ELSE dpa.AccountNumber END;

/*Deceased */
SELECT DISTINCT
        CASE WHEN lu.Allocated_AccountNumber IS NOT NULL THEN lu.Allocated_AccountNumber ELSE da.AccountNumber END AS AccountNumber
      , 1 AS Deceased
INTO    #dec
FROM    P_DW.dbo.factMortgageAccountMonthSS fma
INNER JOIN P_DW.dbo.dimAccount da             ON fma.FK_Account = da.PK_Account
INNER JOIN P_DW.dbo.dimCompany dc             ON fma.FK_Company = dc.PK_Company
INNER JOIN P_DW.dbo.dimMonth dm               ON fma.FK_SnapshotDate = dm.PK_Month
INNER JOIN P_DW.dbo.dimAccountStates das      ON fma.FK_AccountStates = das.PK_AccountStates
INNER JOIN P_DW.dbo.bridgeAccountCustomer bac ON da.PK_Account = bac.FK_Account
INNER JOIN P_DW.dbo.dimCustomer dcu           ON bac.FK_Customer = dcu.PK_Customer
INNER JOIN P_DW.dbo.dimMortgageSecurity dms   ON fma.FK_MortgageSecurity = dms.PK_MortgageSecurity
LEFT JOIN  P_ODS.reference.AHLNYMMigratedAccounts lu
       ON  da.AccountPool = lu.AHLNYM_PoolID AND da.AccountNumber = lu.AHLNYM_AccountNumber
WHERE   dc.CompanyName IN ('Skipton Building Society','Amber Homeloans Ltd','North Yorkshire Mortgages')
AND     da.AccountPool<>'DRC00001'
AND     dm.CalendarMonthYear=(SELECT Yyyymm FROM #params)
AND     da.AccountSubType='Primary'
AND     das.AccountStatus IN ('Live','Possession')
AND     da.CurrentAccountClassification<>'Pure Commercial'
AND     (CASE WHEN dc.CompanyName IN ('Amber Homeloans Ltd','North Yorkshire Mortgages') AND fma.StandardArrearsAmount>0 THEN fma.StandardArrearsAmount
              WHEN dc.CompanyName IN ('Skipton Building Society') AND fma.ContractualArrearsAmount>0 THEN fma.ContractualArrearsAmount
              ELSE 0 END)>0
AND     da.AccountStartDate IS NOT NULL /*Removes Delayed Completions*/
AND     (dcu.CustomerDateofDeath IS NOT NULL OR dms.PostalName LIKE ('%DECD%') OR dms.PostalName LIKE ('%PERS REPS%'));

/*Redemption statement requested in the snapshot month (SAS: previous calendar month relative to GETDATE())*/
SELECT  b.AccountNumber, b.Red_Letter_Sent, 1 AS RedStaInd
INTO    #redsta
FROM   (SELECT a.*, RANK() OVER(PARTITION BY a.AccountNumber ORDER BY a.Red_Letter_Sent DESC, a.oid DESC) AS LastSent
        FROM  (SELECT a98.accnbr_o AS AccountNumber, a98.lettcode_o AS Letter_Code
                    , CONVERT(DATE,a98.dc_creat_o_dt) AS Red_Letter_Sent, a98.oid
               FROM   P_ODS.SKIPCORE.ADM98 a98
               WHERE  a98.pool_id_o='SBS00001'
               AND    a98.lettcode_o IN ('RED001','RED01F','RED01E')
               AND    a98.dc_creat_o_dt BETWEEN (SELECT MonthStart FROM #params) AND EOMONTH((SELECT MonthStart FROM #params))) a) b
WHERE   b.LastSent=1;
