/* 04_outputs: SAS steps 4 (summary), 5 (RAG summary), 6 and 7 (account-level lists + merges).
   One enriched table is built once (core + accounts + CMS + deceased + redemption statement); every list is a selection from it. */

SELECT  c.*
      , CASE WHEN c.MLTAHeld1=1 THEN 'LT12M' WHEN c.MLTAHeld2=1 THEN '12_23M' WHEN c.MLTAHeld3=1 THEN '24M_Plus' END AS HeldGroup
      , CASE WHEN c.M6PDur-12>0 THEN c.M6PDur-12 ELSE 0 END AS LTADur
      , a.Lender, a.AccountOriginal, a.CurrentAccountClassification, a.SubPopulationCode, a.Contractual_MIA, a.Contractual_Arrears
      , a.HPI_Val, a.LTV, a.Rep_Type, a.HPI_Region, a.CompletionYear, a.ArrangementLive, a.Litigation
      , a.EvictionDate, a.PossessionDate, a.ProceedingsWithdrawnDate, a.RedeemedFlag, a.Repossessed_Ind
      , m.CMS_Current, m.CMS_Next
      , d.Deceased
      , r.Red_Letter_Sent, r.RedStaInd
      , DATEDIFF(MONTH,(SELECT MonthStart FROM #params),a.EvictionDate) AS EvMonthIdx
      , ROUND(CAST(c.ExpAB1 AS FLOAT)/NULLIF(CAST(m.CMS_Next AS FLOAT),0),5) AS ExpMIA1
      , ROUND(CAST(c.ExpAB2 AS FLOAT)/NULLIF(CAST(m.CMS_Next AS FLOAT),0),5) AS ExpMIA2
      , ROUND(CAST(c.ExpAB3 AS FLOAT)/NULLIF(CAST(m.CMS_Next AS FLOAT),0),5) AS ExpMIA3
INTO    #enriched
FROM    #core c
LEFT JOIN #accounts a ON a.AccountNumber=c.AccountNumber
LEFT JOIN #cms m      ON m.AccountNumber=c.AccountNumber
LEFT JOIN #dec d      ON d.AccountNumber=c.AccountNumber
LEFT JOIN #redsta r   ON r.AccountNumber=c.AccountNumber;

/* ---- Summary (SAS proc summary, long form: one row per metric; the notebook pivots it to the SAS column layout) ---- */
SELECT  CONCAT(v.Series, CAST(k.K AS VARCHAR(2)), x.Kind) AS Metric, SUM(x.Val) AS Value
INTO    #summary_long
FROM    #core c
CROSS APPLY (VALUES ('M1P',c.M1PDur,c.M1PDurPrev),('M3P',c.M3PDur,c.M3PDurPrev),('M6P',c.M6PDur,c.M6PDurPrev)
                  , ('R1P',c.R1PDur,c.R1PDurPrev),('R3P',c.R3PDur,c.R3PDurPrev),('R6P',c.R6PDur,c.R6PDurPrev)) v(Series,Dur,DurPrev)
CROSS JOIN (VALUES (3),(6),(12),(24)) k(K)
CROSS APPLY (VALUES ('In',   CASE WHEN v.Dur=k.K AND c.Repossessed=0 THEN 1 END)
                  , ('Held', CASE WHEN v.Dur>k.K AND c.Repossessed=0 THEN 1 END)
                  , ('Out',  CASE WHEN v.DurPrev>=k.K AND ((v.Dur=0 AND c.Pos2=0) OR c.RepLM=1) THEN -1 END)) x(Kind,Val)
GROUP BY v.Series, k.K, x.Kind;

INSERT INTO #summary_long (Metric, Value)
SELECT  z.Metric, SUM(z.Val)
FROM    #core c
CROSS APPLY (VALUES ('M',c.M6PDur,c.M6PDurPrev),('R',c.R6PDur,c.R6PDurPrev)) v(P,Dur,DurPrev)
CROSS APPLY (VALUES ('LTAIn',    CASE WHEN v.Dur=12 AND c.Repossessed=0 THEN 1 END,                CASE WHEN v.Dur=12 AND c.Repossessed=0 THEN c.Bal1 END)
                  , ('LTAHeld1', CASE WHEN v.Dur>12 AND v.Dur<=24 AND c.Repossessed=0 THEN 1 END,  CASE WHEN v.Dur>12 AND v.Dur<=24 AND c.Repossessed=0 THEN c.Bal1 END)
                  , ('LTAHeld2', CASE WHEN v.Dur>24 AND v.Dur<=36 AND c.Repossessed=0 THEN 1 END,  CASE WHEN v.Dur>24 AND v.Dur<=36 AND c.Repossessed=0 THEN c.Bal1 END)
                  , ('LTAHeld3', CASE WHEN v.Dur>36 AND c.Repossessed=0 THEN 1 END,                CASE WHEN v.Dur>36 AND c.Repossessed=0 THEN c.Bal1 END)
                  , ('LTAOut',   CASE WHEN v.DurPrev>=12 AND ((v.Dur=0 AND c.Pos2=0) OR c.RepLM=1) THEN -1 END
                               , CASE WHEN v.DurPrev>=12 AND ((v.Dur=0 AND c.Pos2=0) OR c.RepLM=1) THEN c.Bal2 END)) n(Nm,Cnt,Bal)
CROSS APPLY (VALUES (CONCAT(v.P,n.Nm), n.Cnt),(CONCAT(v.P,n.Nm,'_Bal'), n.Bal)) z(Metric,Val)
GROUP BY z.Metric;

INSERT INTO #summary_long (Metric, Value)
SELECT  t.Metric, t.Value
FROM   (SELECT 'Mature' AS Metric, SUM(Mature) AS Value FROM #core
        UNION ALL SELECT 'MatureBal', SUM(MatureBal) FROM #core
        UNION ALL SELECT 'NextIn_1M', SUM(CASE WHEN NextIn_1M=1 THEN 1 END) FROM #core
        UNION ALL SELECT 'NextIn_2M', SUM(CASE WHEN NextIn_2M=1 THEN 1 END) FROM #core
        UNION ALL SELECT 'NextIn_3M', SUM(CASE WHEN NextIn_3M=1 THEN 1 END) FROM #core
        UNION ALL SELECT '_FREQ_', COUNT(*) FROM #core) t;

/* ---- RAG rating of held LTA cases (SAS rag_rating_lta) ---- */
SELECT  e.HeldGroup
      , COUNT(*) AS _FREQ_
      , SUM(CASE WHEN e.Rating='Red'   THEN 1 END) AS Red
      , SUM(CASE WHEN e.Rating='Amber' THEN 1 END) AS Amber
      , SUM(CASE WHEN e.Rating='Green' THEN 1 END) AS Green
INTO    #rag
FROM    #enriched e
WHERE   e.MLTAHeld1+e.MLTAHeld2+e.MLTAHeld3>0
GROUP BY e.HeldGroup;

/* ---- LTA_In / LTA_Out / Held (SAS: in, out, held) in ONE table, split by ListName when exported ---- */
SELECT  x.ListName
      , e.AccountNumber, e.AgeYears, e.MIA, e.Bal1, e.Arr1, e.Rating, e.HeldGroup, e.LTADur
      , e.Lender, e.AccountOriginal, e.CurrentAccountClassification, e.SubPopulationCode, e.Contractual_MIA, e.Contractual_Arrears
      , e.HPI_Val, e.LTV, e.Rep_Type, e.HPI_Region, e.CompletionYear, e.ArrangementLive, e.Litigation
      , e.EvictionDate, e.PossessionDate, e.ProceedingsWithdrawnDate, e.RedeemedFlag, e.Repossessed_Ind
      , e.Deceased, e.Red_Letter_Sent, e.RedStaInd
INTO    #lta_lists
FROM    #enriched e
CROSS APPLY (VALUES ('LTA_In',  e.MLTAIn)
                  , ('LTA_Out', e.MLTAOut)
                  , ('Held',    CASE WHEN e.MLTAHeld1=1 OR e.MLTAHeld2=1 OR e.MLTAHeld3=1 THEN 1 ELSE 0 END)) x(ListName,Flag)
WHERE   x.Flag=1;

/* ---- Next roll-in / roll-out forecasts (SAS NextRoll_In, NextRoll_Out + group logic). Group=0 rows are kept here and
        filtered at export, exactly like SAS (out.NextRoll_* keep them, the Excel sheets do not). ---- */
SELECT  e.AccountNumber, e.AgeYears, e.MIA, e.Bal1, e.Arr1, e.M6PDur, e.Rating, e.AvArrRed, e.ExpAB1, e.ExpAB2, e.ExpAB3
      , e.Lender, e.AccountOriginal, e.SubPopulationCode, e.Contractual_MIA, e.Contractual_Arrears
      , e.HPI_Val, e.LTV, e.Rep_Type, e.HPI_Region, e.CompletionYear, e.ArrangementLive, e.Litigation
      , e.EvictionDate, e.PossessionDate, e.ProceedingsWithdrawnDate, e.RedeemedFlag, e.Repossessed_Ind
      , e.CMS_Current, e.CMS_Next, e.ExpMIA1, e.ExpMIA2, e.ExpMIA3
      , ev.EvFlag, g.Group1, g.Group2, g.Group3
      , CASE WHEN g.Group1=1 THEN 1 WHEN g.Group2=1 THEN 2 WHEN g.Group3=1 THEN 3 ELSE 0 END AS [Group]
      , e.Deceased, e.Red_Letter_Sent, e.RedStaInd
INTO    #nextroll_in
FROM    #enriched e
CROSS APPLY (SELECT CASE WHEN e.EvictionDate IS NULL THEN 0 WHEN e.EvMonthIdx BETWEEN 0 AND 2 THEN e.EvMonthIdx+1 ELSE 0 END AS EvFlag) ev
CROSS APPLY (SELECT CASE WHEN e.NextIn_1M=1 AND e.ExpMIA1>=6 AND ev.EvFlag<>1 THEN 1 ELSE 0 END AS Group1
                  , CASE WHEN e.NextIn_2M=1 AND e.ExpMIA2>=6 AND ev.EvFlag<>2 THEN 1 ELSE 0 END AS Group2
                  , CASE WHEN e.NextIn_3M=1 AND e.ExpMIA3>=6 AND ev.EvFlag<>3 THEN 1 ELSE 0 END AS Group3) g
WHERE   e.NextIn_1M=1 OR e.NextIn_2M=1 OR e.NextIn_3M=1;

SELECT  e.AccountNumber, e.AgeYears, e.MIA, e.Bal1, e.Arr1, e.M6PDur, e.Rating, e.AvArrRed, e.ExpAB1, e.ExpAB2, e.ExpAB3
      , e.Lender, e.AccountOriginal, e.SubPopulationCode, e.Contractual_MIA, e.Contractual_Arrears
      , e.HPI_Val, e.LTV, e.Rep_Type, e.HPI_Region, e.CompletionYear, e.ArrangementLive, e.Litigation
      , e.EvictionDate, e.PossessionDate, e.ProceedingsWithdrawnDate, e.RedeemedFlag, e.Repossessed_Ind
      , e.CMS_Current, e.CMS_Next, e.ExpMIA1, e.ExpMIA2, e.ExpMIA3
      , ev.EvFlag, g.Group1, g.Group2, g.Group3
      , CASE WHEN g.Group1=1 THEN 1 WHEN g.Group2=1 THEN 2 WHEN g.Group3=1 THEN 3 ELSE 0 END AS [Group]
      , e.Deceased, e.Red_Letter_Sent, e.RedStaInd
INTO    #nextroll_out
FROM    #enriched e
CROSS APPLY (SELECT CASE WHEN e.EvictionDate IS NULL THEN 0 WHEN e.EvMonthIdx BETWEEN 1 AND 3 THEN e.EvMonthIdx ELSE 0 END AS EvFlag) ev
/* SAS: a missing ExpMIA counts as smaller than 6, hence the COALESCE */
CROSS APPLY (SELECT CASE WHEN (e.AvArrRed>0 AND e.Rating IN ('Green','Amber') AND COALESCE(e.ExpMIA1,-1E9)<6) OR ev.EvFlag=1 THEN 1 ELSE 0 END AS Group1
                  , CASE WHEN (e.AvArrRed>0 AND e.Rating IN ('Green','Amber') AND COALESCE(e.ExpMIA2,-1E9)<6) OR ev.EvFlag=2 THEN 1 ELSE 0 END AS Group2
                  , CASE WHEN (e.AvArrRed>0 AND e.Rating IN ('Green','Amber') AND COALESCE(e.ExpMIA3,-1E9)<6) OR ev.EvFlag=3 THEN 1 ELSE 0 END AS Group3) g
WHERE   e.MLTAIn=1 OR e.MLTAHeld1=1 OR e.MLTAHeld2=1 OR e.MLTAHeld3=1;
