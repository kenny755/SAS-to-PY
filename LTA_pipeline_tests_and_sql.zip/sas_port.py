"""Independent line-by-line Python port of the SAS logic (strings, INDEX, SUBSTR, SAS missing-value rules).
Written from the SAS source, NOT from the SQL, so agreement between the two is meaningful."""
import pandas as pd, numpy as np, math, datetime as dt
MISSING = -math.inf   # SAS: missing < every number

def sround(x, unit):                      # SAS ROUND(x, unit)
    q = x/unit; r = math.floor(abs(q)+0.5+1e-9)*(1 if q>=0 else -1); return r*unit

def run(tabs, snapshot=dt.date(2026,10,1)):
    T = {**tabs[('P_DW','dbo')], **tabs[('P_ODS','reference')], **tabs[('P_ODS','SKIPCORE')]}
    ym = lambda d: d.year*100+d.month
    def addm(d,n):
        t=d.year*12+d.month-1+n; return dt.date(t//12,t%12+1,1)
    f=T['factMortgageAccountMonthSS']; da=T['dimAccount']; dc=T['dimCompany']; das=T['dimAccountStates']; dp=T['dimProduct']
    dm=T['dimMonth']; dd=T['dimDate']; lu=T['AHLNYMMigratedAccounts']
    base = (f.merge(da,left_on='FK_Account',right_on='PK_Account').merge(dc,left_on='FK_Company',right_on='PK_Company')
             .merge(das,left_on='FK_AccountStates',right_on='PK_AccountStates').merge(dp,left_on='FK_CurrentMortgageProduct',right_on='PK_Product')
             .merge(dm,left_on='FK_SnapshotDate',right_on='PK_Month')
             .merge(dd.rename(columns={'PK_Date':'PKD','CalendarDate':'PossCal','CalendarYear':'PY','CalendarMonthNumber':'PM'}),left_on='FK_PossessionDate',right_on='PKD')
             .merge(lu,how='left',left_on=['AccountPool','AccountNumber'],right_on=['AHLNYM_PoolID','AHLNYM_AccountNumber']))
    base['AccN']=np.where(base.Allocated_AccountNumber.notna(),base.Allocated_AccountNumber,base.AccountNumber)
    end_ym = base.AccountEndDate.apply(lambda d: ym(d) if d is not None and not pd.isna(d) else -1)
    ok = (base.CompanyName.isin(['Skipton Building Society','Amber Homeloans Ltd','North Yorkshire Mortgages'])&(base.AccountPool!='DRC00001')
          &(base.AccountSubType=='Primary')&(base.CurrentAccountClassification!='Pure Commercial')&base.AccountStartDate.notna()
          &~base.ProductCode.isin(['MIN01','HOM10','HM120','HM121','HM122','HM123','HM124','HM125'])
          &(base.AccountStatus.isin(['Live','Possession'])|(base.AccountEndDate.notna()&(end_ym==base.CalendarMonthYear))))
    base=base[ok].copy()
    sbs = base.CompanyName=='Skipton Building Society'
    base['Arr']=np.where(sbs,base.ContractualArrearsAmount,base.StandardArrearsAmount); base['Arr']=np.where(base.Arr>0,base.Arr,0.0)
    base['MIAr']=np.where(sbs,base.ContractualArrearsInMonths,base.StandardArrearsInMonths)
    months=[ym(addm(snapshot,-k)) for k in range(48)]
    mp={m:g for m,g in base.groupby('CalendarMonthYear')}
    def ratio(r): return sround((r.Arr/r.CapitalBalanceLive)*100,1e-6) if (r.Arr>0 and r.CapitalBalanceLive>0) else None
    flags={}   # month index -> {acct: dict}
    for i,m in enumerate(months):
        g=mp.get(m); d={}
        if g is not None:
            for r in g.itertuples():
                rt=ratio(r); 
                d[r.AccN]=dict(M1=r.MIAr>=1,M3=r.MIAr>=3,M6=r.MIAr>=6,R1=(rt is not None and rt>=0.8333),R3=(rt is not None and rt>=2.4999),R6=(rt is not None and rt>=4.9998),
                               Bal=(0 if r.CapitalBalanceLive<=0 else r.CapitalBalanceLive),Arr=r.Arr,Pos=1 if r.AccountStatus=='Possession' else 0)
        flags[i]=d
    core={}
    for r in mp[months[0]].itertuples():
        age_ok = r.AccountStartDate<=r.BatchDate
        days=(r.BatchDate-r.AccountStartDate).days if age_ok else 0
        ay=sround(days/365,0.01) if age_ok else 0
        rt=ratio(r)
        core[r.AccN]=dict(AgeYears=ay,MIA=(sround(r.MIAr,0.001) if r.MIAr>0 else 0),Repossessed=1 if r.AccountStatus=='Possession' else 0,
                          RepLM=1 if (r.PY*100+r.PM)==r.CalendarMonthYear else 0,
                          Mature=1 if (age_ok and ay>=3 and r.CapitalBalanceLive>0) else 0,
                          MatureBal=r.CapitalBalanceLive if (age_ok and ay>=3 and r.CapitalBalanceLive>0) else 0)
    out={}
    for a,c in core.items():
        s={}
        for k in ['M1','M3','M6','R1','R3','R6']:
            s[k]=''.join('Y' if flags[i].get(a,{}).get(k,False) else 'N' for i in range(48))
        c['S']=s; c['Dur']={k:(48 if 'N' not in v else v.index('N')) for k,v in s.items()}
        h=lambda i,fld: flags[i].get(a,{}).get(fld,None)
        c['Bal']=[h(i,'Bal') for i in range(7)]; c['ArrH']=[h(i,'Arr') for i in range(7)]; c['Pos2']=h(1,'Pos')
    return T, base, core, months

def nz(x): return MISSING if x is None else x
def sub(s,a,n): return s[a-1:a-1+n]

def step4_5(core):
    for a,c in core.items():
        S,D=c['S'],c['Dur']; rep=c['Repossessed']; Y=lambda n:'Y'*n
        outc=lambda k: sub(S[k],2,{'M1':0}.get(k,0) or 0)  # placeholder (unused)
        c['F']={}
        for k in ['M1','M3','M6','R1','R3','R6']:
            for n in (3,6,12,24):
                if sub(S[k],1,n)==Y(n) and D[k]==n and rep==0: c['F'][f'{k}P{n}In']=1
                if sub(S[k],1,n)==Y(n) and D[k]>n and rep==0: c['F'][f'{k}P{n}Held']=1
                if sub(S[k],2,n)==Y(n) and ((D[k]==0 and c['Pos2']==0) or c['RepLM']==1): c['F'][f'{k}P{n}Out']=-1
        for p,k in (('M','M6'),('R','R6')):
            if sub(S[k],1,12)==Y(12) and D[k]==12 and rep==0: c['F'][p+'LTAIn']=1; c['F'][p+'LTAIn_Bal']=c['Bal'][0]
            for nm,lo,hi in (('LTAHeld1',12,24),('LTAHeld2',24,36),('LTAHeld3',36,999)):
                if sub(S[k],1,12)==Y(12) and lo<D[k]<=hi and rep==0: c['F'][p+nm]=1; c['F'][p+nm+'_Bal']=c['Bal'][0]
            if sub(S[k],2,12)==Y(12) and ((D[k]==0 and c['Pos2']==0) or c['RepLM']==1): c['F'][p+'LTAOut']=-1; c['F'][p+'LTAOut_Bal']=c['Bal'][1]
        S6=S['M6']; d6=D['M6']
        c['NextIn']=[int(sub(S6,1,12)=='YYYYYYYYYYYN' and d6==11 and rep==0),int(sub(S6,1,11)=='YYYYYYYYYYN' and d6==10 and rep==0),int(sub(S6,1,10)=='YYYYYYYYYN' and d6==9 and rep==0)]
        A=[nz(x) for x in c['ArrH']]
        Det=[int(A[i]>A[i+1]) for i in range(6)]; Imp=[int(A[i]<A[i+1]) for i in range(6)]
        if Det[0]==1 or sum(Det[1:4])>=2: r='Red'
        elif Imp[0] and Imp[1] and Imp[2]: r='Green'
        else: r='Amber'
        c['Rating']=r
        ar=c['ArrH']; red=[]
        for i in range(3):
            x,y=ar[i+1],ar[i]
            red.append(max(0,x-y) if (x is not None and y is not None) else 0)
        med=sorted(red)[1]; c['AvArrRed']=sround(med,1)
        up = r=='Green' or (r=='Amber' and c['AvArrRed']>0)
        c['ExpAB']=[ar[0]-c['AvArrRed']*k if up else ar[0] for k in (1,2,3)]
        F=c['F']
        c['HeldGroup']=('LT12M' if F.get('MLTAHeld1') else '12_23M' if F.get('MLTAHeld2') else '24M_Plus' if F.get('MLTAHeld3') else None)

def summary(core):
    tot={}; 
    for c in core.values():
        for k,v in c['F'].items():
            if v is not None: tot[k]=tot.get(k,0)+v
        tot['Mature']=tot.get('Mature',0)+c['Mature']; tot['MatureBal']=tot.get('MatureBal',0)+c['MatureBal']
        for i,n in enumerate(c['NextIn']):
            if n: tot[f'NextIn_{i+1}M']=tot.get(f'NextIn_{i+1}M',0)+1
    tot['_FREQ_']=len(core); return tot

def lists(T, core, snapshot, acc):
    """acc: dataframe of 'accounts' lookups built independently by the test (EvictionDate, CMS_Next...)."""
    res={'LTA_In':{}, 'LTA_Out':{}, 'Held':{}, 'NextRoll_In':{}, 'NextRoll_Out':{}}
    def evidx(d):
        return None if d is None or pd.isna(d) else (d.year-snapshot.year)*12+d.month-snapshot.month
    for a,c in core.items():
        F=c['F']; info=acc.get(a,{})
        held=any(F.get(x) for x in('MLTAHeld1','MLTAHeld2','MLTAHeld3'))
        if F.get('MLTAIn'): res['LTA_In'][a]=(c['Bal'][0],c['Rating'],c['HeldGroup'],max(0,c['Dur']['M6']-12))
        if F.get('MLTAOut'): res['LTA_Out'][a]=(c['Bal'][0],c['Rating'],c['HeldGroup'],max(0,c['Dur']['M6']-12))
        if held: res['Held'][a]=(c['Bal'][0],c['Rating'],c['HeldGroup'],max(0,c['Dur']['M6']-12))
        cms=info.get('CMS_Next'); ex=[None if not cms else sround(e/cms,0.00001) for e in c['ExpAB']]
        e=evidx(info.get('EvictionDate'))
        if any(c['NextIn']):
            ev=0 if e is None else (e+1 if 0<=e<=2 else 0)
            g=[c['NextIn'][i]==1 and nz(ex[i])>=6 and ev!=i+1 for i in range(3)]
            grp=1 if g[0] else 2 if g[1] else 3 if g[2] else 0
            res['NextRoll_In'][a]=(grp,ex)
        if F.get('MLTAIn') or held:
            ev=0 if e is None else (e if 1<=e<=3 else 0)
            g=[(c['AvArrRed']>0 and c['Rating'] in('Green','Amber') and nz(ex[i])<6) or ev==i+1 for i in range(3)]
            grp=1 if g[0] else 2 if g[1] else 3 if g[2] else 0
            res['NextRoll_Out'][a]=(grp,ex)
    return res
