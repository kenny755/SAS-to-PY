# %% [markdown]
# ## 8. Self-check totals (compare these with SAS – no account data needed)

# %%
tot = []
for name in ["LTA_In", "LTA_Out", "Held"]:
    d = sheets[name]; tot.append((name, len(d), round(float(d.Bal1.sum()), 2), round(float(d.Arr1.sum()), 2)))
for name in ["NextRoll_In", "NextRoll_Out"]:
    d = sheets[name]; tot.append((name, len(d), round(float(d.Bal1.sum()), 2), round(float(d.Arr1.sum()), 2)))
tot.append(("AdditionalLTAData", len(addl_df), None, None)); tot.append(("LTA List", len(ltalist_df), None, None))
selfcheck = pd.DataFrame(tot, columns=["Sheet", "Rows", "Sum Bal1", "Sum Arr1"])
print(selfcheck.to_string(index=False))
print("\nSummary sheet key figures (MIA definition: in / held / out | ATBR definition: in / held / out)")
g = lambda k: vals.get(k) or 0
print(" M:", g("MLTAIn"), g("MLTAHeld1") + g("MLTAHeld2") + g("MLTAHeld3"), g("MLTAOut"),
      "| R:", g("RLTAIn"), g("RLTAHeld1") + g("RLTAHeld2") + g("RLTAHeld3"), g("RLTAOut"))
print("Rating split of held cases:\n", rag_df.to_string(index=False))

# %% [markdown]
# ## 9. Optional – refresh `Report Summary.xlsx` (keeps its charts)
# Off by default (`UPDATE_REPORT_SUMMARY`). Windows + Excel + `pywin32` only. It follows process-note step 2, then
# overwrites the *contents* of the sheets in place (sheets are never deleted, so chart links are not broken).

# %%
PM_COPY = OUT_DIR / "Report Summary - Prev Month.xlsx"   # NB the process note calls this file both "Prev Month" and "PM" - confirm name

def update_report_summary():
    import shutil
    import win32com.client as win32
    if not REPORT_SUMMARY.exists():
        stop(f"{REPORT_SUMMARY} not found")
    if PM_COPY.exists(): PM_COPY.unlink()
    shutil.copy2(REPORT_SUMMARY, PM_COPY)                       # step 2: last month's file kept for forecast-vs-actual
    xl = win32.DispatchEx("Excel.Application"); xl.Visible = False; xl.DisplayAlerts = False
    try:
        wb = xl.Workbooks.Open(str(REPORT_SUMMARY))
        existing = {s.Name: s for s in wb.Worksheets}
        for name, df in sheets.items():
            ws = existing.get(name) or wb.Worksheets.Add(After=wb.Worksheets(wb.Worksheets.Count))
            ws.Name = name
            ws.UsedRange.ClearContents()
            data = [list(df.columns)] + [[None if pd.isna(v) else (v.to_pydatetime() if hasattr(v, "to_pydatetime") else v) for v in row]
                                         for row in df.itertuples(index=False, name=None)]
            ws.Range(ws.Cells(1, 1), ws.Cells(len(data), len(df.columns))).Value = data
        wb.Save(); wb.Close()
    finally:
        xl.Quit()
    print("Report Summary.xlsx refreshed; previous month copy saved as", PM_COPY.name)

if UPDATE_REPORT_SUMMARY:
    update_report_summary()
else:
    print("Skipped (UPDATE_REPORT_SUMMARY = False). Copy the sheets from", main_path.name, "into Report Summary.xlsx as before.")

# %% [markdown]
# ## 10. Outlook draft email (saved as a draft – never sent)
# Edit the wording here if you like. Recipients are resolved by Outlook from names; unresolved names are listed so you can fix them in the draft.

# %%
import html, urllib.parse
nxt = (MONTH_START.replace(day=28) + dt.timedelta(days=4)).replace(day=1)          # report is named for the following month
REPORT_PDF = f"LTA Report {nxt:%y%m} ({YYMM} data).pdf"
ADDL_XLSX  = f"AdditionalLTAData({YYMM}).xlsx"
link = "file:" + urllib.parse.quote(str(SHARED_DIR).replace("\\", "/"), safe="/:")
subject = f"LTA Report {MONTH_START:%B %Y} – now available"
body = f"""<p>Morning all,</p>
<p>A quick reminder that the {MONTH_START:%B %Y} Long Term Arrears (LTA) report and accompanying LTA data file are now available here:</p>
<p><a href="{link}">{html.escape(str(SHARED_DIR))}</a></p>
<p><b>What it covers:</b> LTA volumes and balances at {MONTH_START:%B %Y} month end (MIA and ATBR definitions), accounts rolling in and out,
the 3-month forecast of expected roll-ins and roll-outs, the LTA case profile (forbearance, arrangements, vulnerability) and the pipeline.</p>
<p><b>Files:</b> {html.escape(REPORT_PDF)} and {html.escape(ADDL_XLSX)}.</p>
<p><b>Action:</b> please take a look when you have a moment and let me know if you have any questions or spot anything that needs checking.</p>
<p>Many thanks,</p>"""

missing = [f for f in (REPORT_PDF, ADDL_XLSX) if SHARED_DIR.exists() and not (SHARED_DIR / f).exists()]
if missing: print("WARNING - not yet in the shared folder (copy them there before sending):", missing)

def create_outlook_draft():
    import win32com.client as win32
    ol = win32.Dispatch("Outlook.Application")
    mail = ol.CreateItem(0)
    mail.Subject = subject
    signature = mail.HTMLBody                                   # keeps the default signature
    mail.HTMLBody = body + signature
    for name in EMAIL_TO: mail.Recipients.Add(name).Type = 1
    if RUN_BY_SOMEONE_ELSE:
        for name in EMAIL_CC: mail.Recipients.Add(name).Type = 2
    mail.Recipients.ResolveAll()
    unresolved = [r.Name for r in mail.Recipients if not r.Resolved]
    mail.Save()                                                 # into Drafts - NEVER mail.Send()
    mail.Display(False)
    return unresolved

try:
    unresolved = create_outlook_draft()
    print("Outlook draft created (not sent).", "Unresolved recipients - fix in the draft:" if unresolved else "All recipients resolved.", unresolved or "")
except Exception as e:                                          # no Outlook (e.g. not Windows): write the draft to a file instead
    fallback = OUT_DIR / f"LTA email draft ({YYMM}).html"
    fallback.write_text(f"<p><b>To:</b> {'; '.join(EMAIL_TO)}<br><b>CC:</b> {'; '.join(EMAIL_CC) if RUN_BY_SOMEONE_ELSE else ''}<br>"
                        f"<b>Subject:</b> {subject}</p>{body}", encoding="utf-8")
    print("Outlook not available (", type(e).__name__, ") - draft written to", fallback)

conn.close()
print("\nDone.")
