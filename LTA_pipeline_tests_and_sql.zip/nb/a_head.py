# %% [markdown]
# # Long Term Arrears (LTA) report – SQL pipeline
# Replaces `LTA+Forecast (P_DW & LU Jul-21 onwards).sas`. **Run all cells top to bottom** (VS Code: *Run All*).
# The run **stops with a clear message** if the month-end data is not loaded yet, or if any built-in check fails.
# The email is only ever saved as a **draft** – it is never sent.
#
# Only one input is needed – the first day of the snapshot month (cell 1). Everything else is derived from it.

# %%
# ============ 1. INPUT & SETTINGS ============
import datetime as dt
from pathlib import Path

# ---- the single date input (SAS: %let monthend='01Oct2026'd) ----
# Default = first day of the current month, as per the process note.
# If that month's snapshot is not in the DW yet, the pre-check below stops the run and tells you.
# To run an earlier snapshot type it here, e.g. dt.date(2026, 10, 1)  (must be a 1st of the month).
MONTH_START = dt.date.today().replace(day=1)

# ---- where things go ----
OUT_DIR    = Path(r"H:\Portfolio Management\Long Term Arrears\Detailed MIA Report")   # same as SAS exports
SHARED_DIR = Path(r"\\sbsfiles\Credit_Management_CreditRiskMI\Long Term Arrears")     # for the email link
REPORT_SUMMARY = OUT_DIR / "Report Summary.xlsx"            # workbook that feeds the Word report (charts live in here)

# ---- switches ----
UPDATE_REPORT_SUMMARY   = False   # True = also rotate the previous-month copy and refresh sheets inside Report Summary.xlsx
                                  # (needs Windows + Excel; see section 9). Off by default until you have tried it once.
STOP_ON_DUPLICATE_KEYS  = True    # SAS "merge by AccountNumber" silently misbehaves on duplicate account numbers; stop if found
EXPORT_ACCOUNT_LEVEL    = False   # True = write core/enriched tables to CSV (replacement for the SAS 'out' library, for account checks)
RUN_BY_SOMEONE_ELSE     = False   # True = CC Sam Hutchinson & Anis Naeem on the email (process note: "when run by someone else")

# ---- SQL Server connection (same server/database/Windows login as the SAS libname) ----
SERVER, DATABASE = r"SBSPSQLVS101\MISPSQL01", "P_DW"
ODBC_DRIVER = "SQL Server"        # same driver SAS used; use "ODBC Driver 17 for SQL Server" if you prefer

# ---- email recipients (names are resolved by Outlook; no addresses are stored here) ----
EMAIL_TO = ["Zoe Sharpe", "Sarah Anderton", "Dale McInroy", "Damian Frodsham", "CRM Quality Assurance",
            "Credit Management Seniors", "Phillip Baxendale", "Elisa Powell"]
EMAIL_CC = ["Sam Hutchinson", "Anis Naeem"]

assert MONTH_START.day == 1, "MONTH_START must be the first day of a month"
YYMM = MONTH_START.strftime("%y%m")
print("Snapshot month:", MONTH_START.strftime("%B %Y"), "| sheet suffix:", YYMM)

# %%
# ============ 2. CONNECTION & HELPERS ============
import time, re, warnings
import pandas as pd
import sqlalchemy as sa
from sqlalchemy.engine import URL
warnings.filterwarnings("ignore", category=UserWarning)

class PipelineStop(Exception):
    """Raised to halt the run with a readable message (pre-check or built-in check failed)."""

def stop(msg):
    raise PipelineStop("\n\n  STOPPED: " + msg + "\n")

engine = sa.create_engine(URL.create("mssql+pyodbc", host=SERVER, database=DATABASE,
                          query={"driver": ODBC_DRIVER, "trusted_connection": "yes"}),
                          isolation_level="AUTOCOMMIT")
conn = engine.connect()          # ONE connection for the whole run: the #temp tables live on it

def run_sql(sql, params=None, label=""):
    """Run a T-SQL batch on the session connection."""
    t0 = time.time()
    conn.exec_driver_sql("SET NOCOUNT ON;\n" + sql, params or ())
    if label: print(f"  {label:<28} {time.time()-t0:6.1f}s")

def q(sql):
    """Query -> DataFrame."""
    return pd.read_sql_query(sql, conn)

def scalar(sql):
    return conn.exec_driver_sql(sql).scalar()

print("Connected to", SERVER, "/", DATABASE)

# %% [markdown]
# ## 3. Pre-check – is the month-end data loaded?
# Stops the run if the snapshot is missing/empty, or if any of the 48 history months is empty.

# %%
months = q(f"""SELECT dm.CalendarMonthYear AS Yyyymm, COUNT(f.FK_Account) AS Rows_
               FROM P_DW.dbo.dimMonth dm
               LEFT JOIN P_DW.dbo.factMortgageAccountMonthSS f ON f.FK_SnapshotDate = dm.PK_Month
               WHERE dm.CalendarMonthYear BETWEEN CONVERT(VARCHAR,{(MONTH_START.year-5)*100+MONTH_START.month})
                                              AND CONVERT(VARCHAR,{MONTH_START.year*100+MONTH_START.month})
               GROUP BY dm.CalendarMonthYear""")
months["Yyyymm"] = months["Yyyymm"].astype(str)
have = dict(zip(months.Yyyymm, months.Rows_))
wanted = [(MONTH_START.year*12 + MONTH_START.month-1 - k) for k in range(48)]
wanted = [f"{m//12}{m%12+1:02d}" for m in wanted]

if have.get(wanted[0], 0) == 0:
    stop(f"Snapshot {wanted[0]} is NOT loaded in P_DW yet (factMortgageAccountMonthSS has no rows for it).\n"
         f"  Wait for the month-end load, or set MONTH_START in cell 1 to the latest loaded month "
         f"(latest loaded: {max([m for m, n in have.items() if n > 0], default='none')}).")
empty = [m for m in wanted if have.get(m, 0) == 0]
if empty:
    stop(f"These history months have no data in the fact table: {empty}. The 48-month arrears history would be incomplete.")

ods = {t: scalar(f"SELECT COUNT(*) FROM P_ODS.SKIPCORE.{t}") for t in ["ARR97", "ADM98"]}
if not all(ods.values()):
    stop(f"P_ODS.SKIPCORE tables look empty: {ods}")
print(f"Pre-check passed: snapshot {wanted[0]} has {have[wanted[0]]:,} fact rows; 48 history months present; ODS tables loaded.")
