# %% [markdown]
# ## 5. Built-in checks – any **STOP** failure halts the run; **WARN** is reported but the run continues
# Each query counts violations, so **0 = pass**.

# %%
CHECKS = [
 # (severity, name, SQL returning the number of violations)
 ("STOP","Snapshot accounts all matched to dimDate (SAS core inner-joins it)",
   "SELECT COUNT(*) FROM #fm WHERE MonthOffset=0 AND PossDateMatched=0"),
 ("STOP","All 48 history months present in the extract",
   "SELECT 48-COUNT(DISTINCT MonthOffset) FROM #fm"),
 ("STOP" if STOP_ON_DUPLICATE_KEYS else "WARN","One row per account per month (SAS MERGE BY AccountNumber needs unique keys)",
   "SELECT COUNT(*) FROM (SELECT AccountNumber, MonthOffset FROM #fm GROUP BY AccountNumber, MonthOffset HAVING COUNT(*)>1) d"),
 ("STOP" if STOP_ON_DUPLICATE_KEYS else "WARN","Lookups unique by AccountNumber (accounts, CMS, deceased, redemption statement, arrangements)",
   """SELECT (SELECT COUNT(*) FROM (SELECT AccountNumber FROM #accounts GROUP BY AccountNumber HAVING COUNT(*)>1) a)
         + (SELECT COUNT(*) FROM (SELECT AccountNumber FROM #cms      GROUP BY AccountNumber HAVING COUNT(*)>1) b)
         + (SELECT COUNT(*) FROM (SELECT AccountNumber FROM #dec      GROUP BY AccountNumber HAVING COUNT(*)>1) c)
         + (SELECT COUNT(*) FROM (SELECT AccountNumber FROM #redsta   GROUP BY AccountNumber HAVING COUNT(*)>1) d)
         + (SELECT COUNT(*) FROM (SELECT AccountNumber FROM #arrang   GROUP BY AccountNumber HAVING COUNT(*)>1) e)"""),
 ("STOP","Core rows = snapshot-month rows in the extract",
   "SELECT ABS((SELECT COUNT(*) FROM #core)-(SELECT COUNT(*) FROM #fm WHERE MonthOffset=0))"),
 ("STOP","Enriched table has no extra/missing rows vs core (joins did not multiply rows)",
   "SELECT ABS((SELECT COUNT(*) FROM #enriched)-(SELECT COUNT(*) FROM #core))"),
 ("STOP","Roll-in list rows = summary MLTAIn",
   "SELECT ABS((SELECT COUNT(*) FROM #lta_lists WHERE ListName='LTA_In')-(SELECT COALESCE(Value,0) FROM #summary_long WHERE Metric='MLTAIn'))"),
 ("STOP","Roll-out list rows = -summary MLTAOut",
   "SELECT ABS((SELECT COUNT(*) FROM #lta_lists WHERE ListName='LTA_Out')+(SELECT COALESCE(Value,0) FROM #summary_long WHERE Metric='MLTAOut'))"),
 ("STOP","Held list rows = summary MLTAHeld1+2+3",
   "SELECT ABS((SELECT COUNT(*) FROM #lta_lists WHERE ListName='Held')-(SELECT COALESCE(SUM(Value),0) FROM #summary_long WHERE Metric IN ('MLTAHeld1','MLTAHeld2','MLTAHeld3')))"),
 ("STOP","RAG counts (Red+Amber+Green) = held list rows",
   "SELECT ABS((SELECT COALESCE(SUM(COALESCE(Red,0)+COALESCE(Amber,0)+COALESCE(Green,0)),0) FROM #rag)-(SELECT COUNT(*) FROM #lta_lists WHERE ListName='Held'))"),
 ("STOP","Two independent definitions agree: MLTA (12m) = M6P12 (In and Held)",
   """SELECT ABS(COALESCE((SELECT Value FROM #summary_long WHERE Metric='MLTAIn'),0)-COALESCE((SELECT Value FROM #summary_long WHERE Metric='M6P12In'),0))
         + ABS(COALESCE((SELECT SUM(Value) FROM #summary_long WHERE Metric IN ('MLTAHeld1','MLTAHeld2','MLTAHeld3')),0)-COALESCE((SELECT Value FROM #summary_long WHERE Metric='M6P12Held'),0))"""),
 ("STOP","Summary row count (_FREQ_) = core rows",
   "SELECT ABS((SELECT Value FROM #summary_long WHERE Metric='_FREQ_')-(SELECT COUNT(*) FROM #core))"),
 ("STOP","Every core account has a rating; groups only 0-3",
   "SELECT (SELECT COUNT(*) FROM #core WHERE Rating IS NULL)+(SELECT COUNT(*) FROM #nextroll_in WHERE [Group] NOT IN (0,1,2,3))+(SELECT COUNT(*) FROM #nextroll_out WHERE [Group] NOT IN (0,1,2,3))"),
 ("STOP","Additional-data table has the same rows as the LTA-type list (left join did not multiply rows)",
   "SELECT ABS((SELECT COUNT(*) FROM #addlta)-(SELECT COUNT(*) FROM #new))"),
 ("WARN","Snapshot accounts missing from the account-detail lookup (SAS would leave these blank too)",
   "SELECT COUNT(*) FROM #core c WHERE NOT EXISTS (SELECT 1 FROM #accounts a WHERE a.AccountNumber=c.AccountNumber)"),
 ("WARN","Forecast accounts with no CMS_Next (expected MIA cannot be calculated)",
   "SELECT COUNT(*) FROM #nextroll_in WHERE CMS_Next IS NULL OR CMS_Next=0"),
 ("WARN","No redemption-statement letters found for the month (check ADM98 is loaded)",
   "SELECT CASE WHEN COUNT(*)=0 THEN 1 ELSE 0 END FROM #redsta"),
]
results = []
for sev, name, sql in CHECKS:
    bad = scalar(sql)
    ok = (bad == 0)
    results.append((sev, name, bad, "PASS" if ok else ("FAIL" if sev == "STOP" else "WARN")))
check_df = pd.DataFrame(results, columns=["Severity", "Check", "Violations", "Result"])
display(check_df) if "display" in globals() else print(check_df.to_string())
failed = check_df[(check_df.Severity == "STOP") & (check_df.Result == "FAIL")]
if len(failed):
    stop("Built-in checks failed:\n    - " + "\n    - ".join(failed.Check) + "\n  Nothing has been exported.")
print("All STOP checks passed.", int((check_df.Result == "WARN").sum()), "warning(s).")
