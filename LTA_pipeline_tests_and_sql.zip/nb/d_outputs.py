# %% [markdown]
# ## 6. Build the outputs (same sheets, columns and sort order as the SAS exports)

# %%
# ---- SAS proc summary layout: _TYPE_, _FREQ_, then the VAR list in the SAS order ----
def _series(): return [f"{s}{k}" for s in ["M1P","M3P","M6P","R1P","R3P","R6P"] for k in (3,6,12,24)]
# Order = the proc summary VAR statement in the SAS code
METRIC_ORDER = (["Mature","MatureBal"]
    + [f"MLTA{n}" for n in ["Out","Held1","Held2","Held3","In"]] + [f"MLTA{n}_Bal" for n in ["Out","Held1","Held2","Held3","In"]]
    + [f"RLTA{n}" for n in ["Out","Held1","Held2","Held3","In"]] + [f"RLTA{n}_Bal" for n in ["Out","Held1","Held2","Held3","In"]]
    + [f"{s}{n}" for s in _series() for n in ["Out","Held","In"]]
    + ["NextIn_1M","NextIn_2M","NextIn_3M"])

long = q("SELECT Metric, Value FROM #summary_long")
vals = dict(zip(long.Metric, long.Value))
summary_df = pd.DataFrame([{"_TYPE_": 0, "_FREQ_": vals["_FREQ_"], **{m: vals.get(m) for m in METRIC_ORDER}}])

rag_df = q("SELECT HeldGroup, 1 AS _TYPE_, _FREQ_, Red, Amber, Green FROM #rag ORDER BY HeldGroup")

LIST_SORT = {"LTA_In": "Bal1 DESC, AccountNumber", "LTA_Out": "Bal1 DESC, AccountNumber", "Held": "LTV DESC, AccountNumber"}
lists = {n: q(f"SELECT * FROM #lta_lists WHERE ListName='{n}' ORDER BY {s}").drop(columns="ListName") for n, s in LIST_SORT.items()}
nextroll = {n: q(f"SELECT * FROM #nextroll_{n} WHERE [Group]<>0 ORDER BY [Group], Bal1 DESC, AccountNumber").rename(columns={"Group": "Group"})
            for n in ["in", "out"]}

sheets = {  # sheet name -> DataFrame (same names as the SAS proc exports)
    YYMM: summary_df, f"RAG{YYMM}": rag_df,
    "LTA_In": lists["LTA_In"], "LTA_Out": lists["LTA_Out"], "Held": lists["Held"],
    "NextRoll_In": nextroll["in"], "NextRoll_Out": nextroll["out"]}
addl_df = q("SELECT * FROM #addlta ORDER BY AccountNumber")
ltalist_df = q("SELECT * FROM #lta_list ORDER BY AccountNumber")
print({k: len(v) for k, v in sheets.items()}, "| AdditionalLTAData:", len(addl_df), "| LTA List:", len(ltalist_df))

# %% [markdown]
# ## 7. Excel output – every data sheet has a matching `Doc_` sheet

# %%
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

RUN_STAMP = dt.datetime.now().strftime("%Y-%m-%d %H:%M")
SNAP = MONTH_START.strftime("%B %Y")
COLS = {  # column dictionary (descriptions written from the SAS logic)
 "AccountNumber": "Account number; for migrated AHL/NYM accounts the allocated (SBS) number from P_ODS.reference.AHLNYMMigratedAccounts",
 "AgeYears": "Years from account start to snapshot BatchDate, rounded to 2dp (0 if start is after BatchDate)",
 "MIA": "Months in arrears at snapshot (contractual for SBS, standard for AHL/NYM), rounded to 3dp; 0 if not in arrears",
 "Bal1": "Capital balance at snapshot month (negative balances shown as 0)", "Arr1": "Arrears amount at snapshot month",
 "Rating": "Payment RAG from last 4-7 months' arrears: Red = rising now or at least 2 rises in prior 3 months; Green = falling 3 months running; else Amber",
 "HeldGroup": "How long a held LTA case has been LTA: LT12M, 12_23M, 24M_Plus (blank for roll-ins/roll-outs)",
 "LTADur": "Months beyond the 12-month threshold that the case has been in 6+ MIA (M6PDur-12, min 0)",
 "Lender": "AHL / NYM / SBS", "AccountOriginal": "Account number before migration mapping",
 "CurrentAccountClassification": "Residential / BTL etc. from dimAccount", "SubPopulationCode": "Sub-population (BTL or other)",
 "Contractual_MIA": "Unrounded MIA at snapshot", "Contractual_Arrears": "Arrears amount at snapshot",
 "HPI_Val": "Indexed valuation", "LTV": "HPI LTV rounded to 1dp (Held sheet is sorted by this, descending)",
 "Rep_Type": "C&I / P&P / I/O", "HPI_Region": "ONS region code", "CompletionYear": "Year of account start",
 "ArrangementLive": "Y if an arrangement type code of 1 or more is in place", "Litigation": "Y if proceedings issued and not withdrawn/possessed (ARR97)",
 "EvictionDate": "Eviction date from ARR97", "PossessionDate": "Possession date from ARR97", "ProceedingsWithdrawnDate": "Proceedings withdrawn date from ARR97",
 "RedeemedFlag": "1 if account ended before the snapshot month", "Repossessed_Ind": "Y if account status is Possession",
 "Deceased": "1 if a customer date of death exists or PostalName contains DECD / PERS REPS (arrears accounts only)",
 "Red_Letter_Sent": "Latest redemption statement letter date in the snapshot month (RED001/RED01F/RED01E)", "RedStaInd": "1 if a redemption statement was requested",
 "M6PDur": "Consecutive months in 6+ MIA up to the snapshot", "AvArrRed": "Median monthly arrears reduction over last 3 months (whole pounds)",
 "ExpAB1": "Expected arrears balance in 1 month (Green, or Amber with reduction > 0, else unchanged)", "ExpAB2": "... in 2 months", "ExpAB3": "... in 3 months",
 "CMS_Current": "Contractual monthly payment this month (summed over linked accounts)", "CMS_Next": "Contractual monthly payment next month",
 "ExpMIA1": "ExpAB1 / CMS_Next", "ExpMIA2": "ExpAB2 / CMS_Next", "ExpMIA3": "ExpAB3 / CMS_Next",
 "EvFlag": "1/2/3 if eviction falls in the month the forecast refers to (roll-in: months 0-2; roll-out: months 1-3), else 0",
 "Group1": "Qualifies for roll-in/out within 1 month", "Group2": "... 2 months", "Group3": "... 3 months",
 "Group": "Earliest month group (1-3) the case qualifies for; rows with 0 are removed from the sheet",
 "AccType": "BTL or Resi", "LTAType": "RolledIn, Held<12M, 12M<=Held<23M, Held>=24M, NextRollIn1M/2M/3M",
 "ArrangementCode": "Arrangement type code", "ArrangementDesc": "Arrangement description", "ArrangementEndDate": "Arrangement end date",
 "NoAcc": "Number of accounts under the primary account", "CMS": "Contractual monthly payment (all linked accounts)", "ArrangementAmn": "Arrangement amount (0 if none)",
 "Paid": "Payments this month", "BrokenArrangement": "1 if payments fell short of the arrangement (rules per arrangement type, shortfall > 5 pounds for 'other')",
 "ARFlag": "1 if a customer on the account has an active vulnerability recorded", "_TYPE_": "SAS proc summary column (kept so the layout matches)",
 "_FREQ_": "Number of accounts summarised", "Red": "Held cases rated Red", "Amber": "Held cases rated Amber", "Green": "Held cases rated Green",
}
DOCS = {
 YYMM: ("Summary of movements for the snapshot month (SAS: dataset 'summary' / proc summary)", "One row of totals over all snapshot accounts. Naming: <M|R><LTA or xP><threshold><Out|Held|In>; M = months-in-arrears definition, R = arrears-to-balance-ratio definition; _Bal = balance. Out is negative (-1 per case). Blank = no cases."),
 f"RAG{YYMM}": ("RAG rating of held LTA cases by time held (SAS: rag_rating_lta)", "One row per HeldGroup for cases that are held in LTA (MLTAHeld1/2/3)."),
 "LTA_In": ("Accounts that rolled INTO LTA this month (6+ MIA for exactly 12 months, not repossessed) (SAS: in)", "Sorted by Bal1 descending."),
 "LTA_Out": ("Accounts that rolled OUT of LTA this month (SAS: out)", "6+ MIA in the previous 12 months and now cured/redeemed (or repossessed in month). Sorted by Bal1 descending."),
 "Held": ("Accounts already in LTA and still there (SAS: held)", "6+ MIA for more than 12 months, not repossessed. Sorted by LTV descending."),
 "NextRoll_In": ("Forecast roll-ins in the next 1-3 months (SAS: NextRoll_In, Group<>0)", "Cases 9-11 months into 6+ MIA whose expected MIA stays >= 6 and that have no eviction in the roll month. Sorted by Group, Bal1 descending."),
 "NextRoll_Out": ("Forecast roll-outs in the next 1-3 months (SAS: NextRoll_Out, Group<>0)", "Current roll-ins and held cases that are expected to drop below 6 MIA (improving Green/Amber) or are evicted. Sorted by Group, Bal1 descending."),
 "AdditionalLTAData": ("Arrangement, performance and vulnerability data for roll-in, held and next roll-in cases (SAS: AddLTAdata)", "Sorted by AccountNumber. Use a pivot on ArrangementDesc x LTAType (excluding NextRollIn types) for the email narrative."),
 "LTA List": ("List of LTA cases (roll-in and held) with lender (SAS: lta)", "Sorted by AccountNumber."),
}

def style_header(ws):
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor="305496")
    ws.freeze_panes = "B2"

def write_book(path, frames, doc_keys=None):
    """frames: {sheet: DataFrame}. Writes each frame + a Doc_ sheet + a README index; then re-reads the file to verify row counts."""
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(path, engine="openpyxl", date_format="yyyy-mm-dd", datetime_format="yyyy-mm-dd") as xw:
        idx = []
        for name, df in frames.items():
            df = df.copy()
            for c in df.columns:
                if df[c].dtype == object and df[c].map(lambda v: isinstance(v, (dt.date, dt.datetime)) or v is None).all() and df[c].notna().any():
                    df[c] = pd.to_datetime(df[c])
            df.to_excel(xw, sheet_name=name, index=False)
            purpose, notes = DOCS.get(name, ("", ""))
            rows = [("Sheet", name), ("Purpose", purpose), ("Snapshot month", SNAP), ("Generated", RUN_STAMP),
                    ("Rows", len(df)), ("Notes", notes), ("Source", "SQL pipeline (LTA notebook); P_DW and P_ODS, Windows login"), ("", ""), ("Column", "Description")]
            rows += [(c, COLS.get(c, "")) for c in df.columns]
            pd.DataFrame(rows).to_excel(xw, sheet_name=f"Doc_{name}"[:31], index=False, header=False)
            idx.append((name, f"Doc_{name}"[:31], purpose, len(df)))
        pd.DataFrame(idx, columns=["Sheet", "Documentation sheet", "Purpose", "Rows"]).to_excel(xw, sheet_name="README", index=False)
    wb = load_workbook(path)
    for name in frames:
        style_header(wb[name])
        for i, col in enumerate(frames[name].columns, 1):
            wb[name].column_dimensions[get_column_letter(i)].width = max(10, min(28, len(str(col)) + 3))
        d = wb[f"Doc_{name}"[:31]]; d.column_dimensions["A"].width = 30; d.column_dimensions["B"].width = 110
        for r in d.iter_rows(min_row=1, max_row=9):
            r[0].font = Font(bold=True)
    wb["README"].column_dimensions["C"].width = 100
    wb.move_sheet("README", offset=-len(wb.sheetnames) + 1)
    wb.save(path)
    # verification: re-open and compare row counts with what we meant to write
    wb = load_workbook(path, read_only=True)
    for name, df in frames.items():
        n = wb[name].max_row - 1
        if n != len(df):
            stop(f"Excel verification failed for sheet {name}: file has {n} rows, expected {len(df)}")
    return path

main_path  = write_book(OUT_DIR / f"LTA Pipeline Output ({YYMM}).xlsx", sheets)
addl_path  = write_book(OUT_DIR / f"AdditionalLTAData({YYMM}).xlsx", {"AdditionalLTAData": addl_df})
lista_path = write_book(OUT_DIR / "LTA List.xlsx", {"LTA List": ltalist_df})
print("Written:\n ", main_path, "\n ", addl_path, "\n ", lista_path)

if EXPORT_ACCOUNT_LEVEL:
    d = OUT_DIR / f"AccountLevel_{YYMM}"; d.mkdir(exist_ok=True)
    for t in ["core", "enriched", "nextroll_in", "nextroll_out"]:
        q(f"SELECT * FROM #{t}").to_csv(d / f"{t}.csv", index=False)
    print("Account-level files in", d)
