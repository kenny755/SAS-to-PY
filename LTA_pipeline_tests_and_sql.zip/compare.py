import sys, math, duckdb, pandas as pd, datetime as dt, synth, sas_port as sp, run_sql_test as rt
snap=dt.date(2026,10,1)
con=duckdb.connect(); tabs=synth.build(con)
import test_harness as th
for f in ['00_params.sql','01_base.sql','02_core.sql','02b_core_flags.sql','03_lookups.sql','04_outputs.sql','05_additional.sql']: th.run_file(con,f,str(snap))
T,base,core,months=sp.run(tabs,snap); sp.step4_5(core)
bad=0
def chk(name,ok,detail=''):
    global bad
    print(('PASS ' if ok else 'FAIL ')+name+(' '+detail if (detail and not ok) else '')); bad+= (not ok)
# population
sql_core=con.execute('select AccountNumber from core').df().AccountNumber
chk('core population', set(sql_core)==set(core) and len(sql_core)==len(core), f'{len(sql_core)} vs {len(core)}')
# Durations
d=con.execute('select AccountNumber,M1PDur,M3PDur,M6PDur,R1PDur,R3PDur,R6PDur from core').df().set_index('AccountNumber')
mis=[a for a in core if any(d.loc[a,k+'PDur']!=core[a]['Dur'][k] for k in ['M1','M3','M6','R1','R3','R6'])]
chk('durations (48-month runs)',not mis,str(mis[:5]))
# rating / avarrred / expAB / heldgroup
e=con.execute('select AccountNumber,Rating,AvArrRed,ExpAB1,ExpAB2,ExpAB3,HeldGroup from enriched').df().set_index('AccountNumber')
mis=[a for a in core if e.loc[a,'Rating']!=core[a]['Rating'] or abs(e.loc[a,'AvArrRed']-core[a]['AvArrRed'])>1e-9 or any(abs(float(e.loc[a,f'ExpAB{i+1}'])-core[a]['ExpAB'][i])>1e-6 for i in range(3)) or (e.loc[a,'HeldGroup'] if isinstance(e.loc[a,'HeldGroup'],str) else None)!=core[a]['HeldGroup']]
chk('rating / AvArrRed / ExpAB / HeldGroup',not mis,str(mis[:5]))
# summary
sl=dict(con.execute('select Metric,Value from summary_long').fetchall()); ref=sp.summary(core)
mism=[(k,sl.get(k),ref.get(k)) for k in set(sl)|set(ref) if not (abs((sl.get(k) or 0)-(ref.get(k) or 0))<1e-6)]
chk('summary metrics (%d metrics)'%len(set(ref)|set(sl)),not mism,str(mism[:6]))
# RAG
rag=con.execute('select HeldGroup,_FREQ_,coalesce(Red,0),coalesce(Amber,0),coalesce(Green,0) from rag').fetchall()
refrag={}
for c in core.values():
    if c['HeldGroup']: g=refrag.setdefault(c['HeldGroup'],[0,0,0,0]); g[0]+=1; g['RAG'.index('R')+1 if False else {'Red':1,'Amber':2,'Green':3}[c['Rating']]]+=1
chk('RAG table',{r[0]:list(r[1:]) for r in rag}==refrag,str(rag)+str(refrag))
# accounts lookups from SQL (lookups tested separately by row counts) used as input to ref lists
acc=con.execute('select a.AccountNumber,a.EvictionDate,m.CMS_Next from accounts a left join cms m using(AccountNumber)').df()
accd={r.AccountNumber:dict(EvictionDate=(None if pd.isna(r.EvictionDate) else r.EvictionDate),CMS_Next=(None if pd.isna(r.CMS_Next) else r.CMS_Next)) for r in acc.itertuples()}
L=sp.lists(T,core,snap,accd)
for ln in ['LTA_In','LTA_Out','Held']:
    q=con.execute(f"select AccountNumber,Bal1,Rating,HeldGroup,LTADur from lta_lists where ListName='{ln}'").df()
    got={r.AccountNumber:(r.Bal1,r.Rating,None if pd.isna(r.HeldGroup) else r.HeldGroup,r.LTADur) for r in q.itertuples()}
    chk(f'{ln} ({len(got)} rows)', got==L[ln] and len(q)==len(L[ln]), f'{len(got)} vs {len(L[ln])}')
for n,t in (('NextRoll_In','nextroll_in'),('NextRoll_Out','nextroll_out')):
    q=con.execute(f'select AccountNumber,"Group" from {t}').df()
    got=dict(zip(q.AccountNumber,q.Group)); ref={a:v[0] for a,v in L[n].items()}
    chk(f'{n} groups ({len(got)} rows; non-zero {sum(1 for v in got.values() if v)})',got==ref,str([(a,got.get(a),ref.get(a)) for a in set(got)|set(ref) if got.get(a)!=ref.get(a)][:5]))
print('NON-ZERO groups In/Out:',sum(1 for v in L['NextRoll_In'].values() if v[0]),sum(1 for v in L['NextRoll_Out'].values() if v[0]))
print('RESULT:', 'ALL PASS' if not bad else f'{bad} FAILURES')
