"""Run the pipeline SQL files on DuckDB (T-SQL transpiled by sqlglot) against synthetic data."""
import re, sqlglot, duckdb, pathlib
SQL_DIR = pathlib.Path(__file__).parent / 'sql'

def prep(sql, month_start):
    sql = re.sub(r'/\*.*?\*/', '', sql, flags=re.S)           # drop block comments
    sql = sql.replace('?', f"'{month_start}'")
    return sql

def run_file(con, name, month_start):
    sql = prep((SQL_DIR / name).read_text(), month_start)
    for stmt in sqlglot.parse(sql, read='tsql'):
        out = stmt.sql(dialect='duckdb')
        # SELECT ... INTO #t  ->  CREATE TABLE t AS SELECT ...
        into = stmt.args.get('into')
        if into is not None:
            tname = into.this.name if hasattr(into.this,'name') else str(into.this)
            stmt2 = stmt.copy(); stmt2.set('into', None)
            out = f"CREATE TABLE {tname.lstrip('#')} AS " + stmt2.sql(dialect='duckdb')
        out = out.replace('INNER JOIN LATERAL','CROSS JOIN LATERAL')
        out = out.replace('WITH n AS','WITH RECURSIVE n AS')
        out = re.sub(r'#(\w+)', r'\1', out)
        con.execute(out)
