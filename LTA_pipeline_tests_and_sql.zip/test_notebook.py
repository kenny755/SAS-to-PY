"""Executes the notebook's Python cells against the synthetic DuckDB warehouse (T-SQL transpiled), skipping only the real-connection cells."""
import re, sys, datetime as dt, pathlib, tempfile, nbformat, duckdb, pandas as pd, sqlglot, synth, test_harness as th
OUT = pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else pathlib.Path(tempfile.mkdtemp())
con = duckdb.connect(); synth.build(con)

def tr(stmt_sql):
    outs=[]
    for st in sqlglot.parse(re.sub(r'/\*.*?\*/','',stmt_sql,flags=re.S).replace('SET NOCOUNT ON;',''), read='tsql'):
        if st is None: continue
        into=st.args.get('into'); o=st.sql(dialect='duckdb')
        if into is not None:
            s2=st.copy(); s2.set('into',None); o=f"CREATE TABLE {into.this.name.lstrip('#')} AS "+s2.sql(dialect='duckdb')
        o=o.replace('INNER JOIN LATERAL','CROSS JOIN LATERAL').replace('WITH n AS','WITH RECURSIVE n AS')
        outs.append(re.sub(r'#(\w+)',r'\1',o))
    return outs
class _R:
    def __init__(s,r): s.r=r
    def scalar(s): return s.r[0][0]
class Conn:
    def exec_driver_sql(self, sql, params=()):
        if params: sql=sql.replace('?',f"'{params[0]}'")
        res=None
        for o in tr(sql):
            res=con.execute(o)
        return _R(res.fetchall()) if res is not None and res.description else None
    def close(self): pass
ns={}
nb=nbformat.read('LTA_Report_Pipeline.ipynb',4)
for i,c in enumerate(nb.cells):
    if c.cell_type!='code': continue
    src=c.source
    if 'create_engine' in src:   # connection cell: keep helpers, swap engine/conn
        src=src.split('engine = ')[0]+"conn = None\n"+src[src.index('def run_sql'):]
        src=src.replace('print("Connected to", SERVER, "/", DATABASE)','')
    if 'months = q(' in src:  continue                      # pre-check queries real dimMonth with SQL Server-only syntax; tested separately
    if i==1: src+= f"\nimport pathlib\nMONTH_START=dt.date(2026,10,1); YYMM='2610'; OUT_DIR=pathlib.Path(r'{OUT}'); SHARED_DIR=pathlib.Path('/nonexistent/share')"
    exec(compile(src,f'cell{i}','exec'),ns)
    if 'create_engine' in c.source:
        ns['conn']=Conn()
        import pandas as pd
        ns['q']=lambda sql: con.execute(tr(sql)[0]).df()
print('NOTEBOOK RAN OK; outputs in',OUT)
print(sorted(p.name for p in OUT.iterdir()))
