"""Synthetic warehouse (no real data) with deliberate edge cases. Builds P_DW / P_ODS schemas in DuckDB."""
import numpy as np, pandas as pd, datetime as dt, duckdb

def month_start(y, m): return dt.date(y, m, 1)
def add_months(d, n):
    t = d.year*12 + d.month-1 + n
    return dt.date(t//12, t%12+1, 1)

def build(con, snapshot=dt.date(2026,10,1), n_acc=1500, seed=7):
    rng = np.random.default_rng(seed)
    months = [add_months(snapshot, -k) for k in range(60)]            # 60 months available (48 needed)
    yyyymm = lambda d: d.year*100+d.month
    # ---- dimensions
    dimMonth = pd.DataFrame({'PK_Month': range(1,61),
        'CalendarMonthYear': [yyyymm(d) for d in months[::-1]],
        'BatchDate': [add_months(d,1)-dt.timedelta(days=1) for d in months[::-1]],
        'ReportingMonth': [d for d in months[::-1]]})
    mk = dict(zip(dimMonth.CalendarMonthYear, dimMonth.PK_Month))
    dates = pd.date_range('2015-01-01','2027-12-31')
    dimDate = pd.DataFrame({'PK_Date': range(1,len(dates)+1),'CalendarDate': dates.date,
                            'CalendarYear': dates.year,'CalendarMonthNumber': dates.month})
    dimDate = pd.concat([pd.DataFrame({'PK_Date':[0],'CalendarDate':[dt.date(1900,1,1)],'CalendarYear':[1900],'CalendarMonthNumber':[1]}), dimDate])
    dkey = dict(zip(dimDate.CalendarDate, dimDate.PK_Date))
    dimCompany = pd.DataFrame({'PK_Company':[1,2,3],'CompanyName':['Skipton Building Society','Amber Homeloans Ltd','North Yorkshire Mortgages']})
    dimAccountStates = pd.DataFrame({'PK_AccountStates':[1,2,3],'AccountStatus':['Live','Possession','Redeemed']})
    prods = ['P1','P2','P3','MIN01','HM121','HOM10']
    dimProduct = pd.DataFrame({'PK_Product':range(1,7),'ProductCode':prods})
    dimRepaymentType = pd.DataFrame({'PK_RepaymentType':[1,2,3],'RepaymentTypeGroup':['Capital & Interest','Part & Part','Interest Only']})
    dimMortgageSecurity = pd.DataFrame({'PK_MortgageSecurity':[1,2,3],'ONSRegionCode':['E1','E2','E3'],'PostalName':['MR SMITH','MRS JONES DECD','X PERS REPS']})
    dimSubPopulation = pd.DataFrame({'PK_SubPopulation':[1,2],'SubPopulationCode':['BTL','RES']})
    arr = [(-1,'None'),(5,'Direct debit'),(6,'Concession'),(63,'DWP a'),(65,'DWP b'),(68,'DWP c'),(7,'Other')]
    dimArrangement = pd.DataFrame({'PK_ArrangementType':range(1,8),'ArrangementTypeCode':[a for a,_ in arr],'ArrangementDescription':[b for _,b in arr]})
    # ---- accounts
    A=[]; F=[]; lu=[]; ar97=[]; adm98=[]; bridge=[]; cust=[]
    for i in range(n_acc):
        comp = rng.choice([1,2,3],p=[.7,.15,.15]); pool = {1:'SBS00001',2:'AHL00001',3:'NYM00001'}[comp]
        if rng.random()<.01: pool='DRC00001'
        num=f'A{i:06d}'
        start_off = int(rng.integers(0,200)); start = add_months(snapshot,-start_off)+dt.timedelta(days=int(rng.integers(0,27)))
        if rng.random()<.01: start=None
        cls = rng.choice(['Residential','Residential','Residential','Pure Commercial'],p=[.5,.3,.18,.02])
        sub = 'Primary' if rng.random()>.03 else 'Secondary'
        prod = int(rng.choice(range(1,7),p=[.3,.3,.3,.04,.03,.03]))
        bal = float(rng.integers(20000,300000)); cms=float(rng.integers(150,1500))
        # arrears path (months in arrears, oldest -> newest) as a Markov chain
        life = min(start_off, 59) if start is not None else 12
        path=[]; m=0.0
        entry = rng.random()<.25  # about a quarter are 'problem' accounts
        for t in range(life,-1,-1):
            if entry:
                r=rng.random()
                if m==0: m = float(rng.choice([0,0,1,2])) if r<.3 else 0.0
                elif r<.70: m += 1.0
                elif r<.82: m = max(0.0, m-float(rng.choice([1,2,3])))
                elif r<.86: m = 0.0
                elif r<.90: m += float(rng.choice([.99,1.01,.5]))
            path.append(m)
        # path[j] is month offset life-j ; redemption in last life month for ~3%
        red_off = int(rng.integers(0,6)) if rng.random()<.03 else None
        poss_off = int(rng.integers(0,6)) if (rng.random()<.03 and max(path)>=6) else None
        end = add_months(snapshot,-red_off)+dt.timedelta(days=5) if red_off is not None else None
        A.append(dict(PK_Account=i+1,AccountNumber=num,AccountPool=pool,AccountSubType=sub,CurrentAccountClassification=cls,
                      AccountStartDate=start,AccountEndDate=end,AccountOrigin=('Amber Homeloans Ltd' if comp==2 else 'Skipton Building Society'),
                      CurrentAccountStatus='Live'))
        if comp in (2,3) and rng.random()<.5:
            lu.append(dict(AHLNYM_PoolID=pool,AHLNYM_AccountNumber=num,Allocated_AccountNumber=f'M{i:06d}',Allocated_PrimaryAccount=f'M{i:06d}'))
        for j,mv in enumerate(path):
            off = life-j
            if off>59: continue
            if red_off is not None and off<red_off: continue            # gone after redemption month
            if rng.random()<.01 and off>0: continue                      # a genuinely missing month
            ym = yyyymm(add_months(snapshot,-off))
            status = 3 if (red_off is not None and off==red_off) else (2 if (poss_off is not None and off<=poss_off) else 1)
            if status==3: status=1                                       # redemption-month row is still 'Live' with an end date
            pd_key = dkey[add_months(snapshot,-poss_off)+dt.timedelta(days=3)] if (poss_off is not None and off<=poss_off) else 0
            arrm = float(mv); amt = round(arrm*cms,2)
            F.append(dict(FK_Account=i+1,FK_PrimaryAccount=i+1,FK_Company=int(comp),FK_AccountStates=status,FK_CurrentMortgageProduct=prod,
                FK_SnapshotDate=mk[ym],FK_PossessionDate=pd_key,FK_RepaymentType=int(rng.integers(1,4)),FK_MortgageSecurity=int(rng.integers(1,4)),
                FK_SubPopulation=int(rng.integers(1,3)),FK_ArrangementType=int(rng.integers(1,8)),FK_DatePaymentArrangementEnd=0,
                CapitalBalanceLive=(0.0 if rng.random()<.01 else bal),
                StandardArrearsAmount=(amt if comp!=1 else 0.0),ContractualArrearsAmount=(amt if comp==1 else 0.0),
                StandardArrearsInMonths=(arrm if comp!=1 else 0.0),ContractualArrearsInMonths=(arrm if comp==1 else 0.0),
                HalifaxValuation=bal*1.4,**{'HPI LTV':round(float(rng.uniform(30,110)),3)},
                AccountCMSCurrent=cms,AccountCMSNextMonth=(cms if rng.random()>.05 else 0.0),
                AccountContractualPaymentArrangement=float(rng.choice([0,1,50,cms])),AccountPaymentThisMonth=float(rng.choice([0,cms/2,cms,cms*2]))))
        if pool=='SBS00001' and rng.random()<.2:
            ar97.append(dict(accnbr_o=num,pool_id_o='SBS00001',oid=1,_timestamp=dt.datetime(2026,1,1),dc_ins_o_dt=dt.date(2026,1,5) if rng.random()<.5 else None,
                             dc_wdrwn_o_dt=None,dc_poses_o_dt=None,
                             dc_evict_o_dt=(add_months(snapshot,int(rng.integers(0,5)))+dt.timedelta(days=9)) if rng.random()<.4 else None))
            ar97.append(dict(accnbr_o=num,pool_id_o='SBS00001',oid=0,_timestamp=dt.datetime(2025,1,1),dc_ins_o_dt=None,dc_wdrwn_o_dt=None,dc_poses_o_dt=None,dc_evict_o_dt=None))
        if pool=='SBS00001' and rng.random()<.15:
            adm98.append(dict(accnbr_o=num,pool_id_o='SBS00001',lettcode_o='RED001',dc_creat_o_dt=dt.datetime(2026,10,int(rng.integers(1,31)),0,0),oid=int(rng.integers(1,9))))
        bridge.append(dict(FK_Account=i+1,FK_Customer=i+1,DeLinkDate=None,relationshipTypeCode=19))
        cust.append(dict(PK_Customer=i+1,CustomerNumber=f'C{i}',CustomerDateofDeath=(dt.date(2026,5,5) if rng.random()<.03 else None)))
    dimAccount=pd.DataFrame(A); fact=pd.DataFrame(F)
    fact['FK_Account']=fact['FK_Account'].astype(int)
    vul=pd.DataFrame({'oid':range(1,60),'myCustomer':range(1,60),'removalDate':[None]*59})
    tables = {
     ('P_DW','dbo'):dict(dimMonth=dimMonth,dimDate=dimDate,dimCompany=dimCompany,dimAccountStates=dimAccountStates,dimProduct=dimProduct,
        dimRepaymentType=dimRepaymentType,dimMortgageSecurity=dimMortgageSecurity,dimSubPopulation=dimSubPopulation,dimArrangement=dimArrangement,
        dimAccount=dimAccount,factMortgageAccountMonthSS=fact,factMortgageAccount=fact[['FK_Account']].drop_duplicates(),
        bridgeAccountCustomer=pd.DataFrame(bridge),dimCustomer=pd.DataFrame(cust)),
     ('P_ODS','reference'):dict(AHLNYMMigratedAccounts=pd.DataFrame(lu,columns=['AHLNYM_PoolID','AHLNYM_AccountNumber','Allocated_AccountNumber','Allocated_PrimaryAccount'])),
     ('P_ODS','SKIPCORE'):dict(ARR97=pd.DataFrame(ar97),ADM98=pd.DataFrame(adm98),DatCustomerVulnerability=vul,
        CUS01=pd.DataFrame({'oid':range(1,60),'custnbr_u':[f'C{i}' for i in range(59)],'fndr_id_o':['SBS']*59}),
        DatCustomerVulnerability_allMyCategories=pd.DataFrame({'DatCustomerVulnerability_oid':range(1,60),'StcVulnerabilityCategory_oid':[1]*59}),
        StcVulnerabilityCategory=pd.DataFrame({'oid':[1],'value':['X']}))}
    for (db,sch),tabs in tables.items():
        try: con.execute(f"ATTACH ':memory:' AS {db}")
        except Exception: pass
        con.execute(f"CREATE SCHEMA IF NOT EXISTS {db}.{sch}")
        for n,df in tabs.items():
            con.register('tmp_df',df); con.execute(f'CREATE TABLE {db}.{sch}.{n} AS SELECT * FROM tmp_df'); con.unregister('tmp_df')
    return tables
